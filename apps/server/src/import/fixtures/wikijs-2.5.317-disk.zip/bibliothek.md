---
title: Über die Bibliothek
description: Seite, die zugleich Ordner ist
published: true
date: 2026-10-28T21:09:45.314Z
tags: bibliothek, öffentliche bibliothek
editor: markdown
dateCreated: 2026-10-28T21:09:37.430Z
---

# Über die Bibliothek

Die Stadtbibliothek Eichenau ist eine öffentliche Bibliothek mit zwei Standorten.

## Unterseiten

- [Geschichte](geschichte)
- [Team](/de/bibliothek/team)
- [Öffnungszeiten](/de/bibliothek/%C3%B6ffnungszeiten)
- [Standorte](standorte)
- [Hauptstelle](standorte/hauptstelle)
{.grid-list}

Ein Link auf eine Unterseite, die es nicht gibt: [Förderverein](foerderverein).
