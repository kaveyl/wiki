---
title: 100 % Lesespaß – Aktion für Groß & Klein
description: Prozent und Und-Zeichen
published: true
date: 2026-10-28T21:10:54.926Z
tags: aktion, lese spaß
editor: markdown
dateCreated: 2026-10-28T21:10:54.224Z
---

# 100 % Lesespaß

Titel mit `%`, `&` und `ß`. Link mit Prozent im Text: [50 % Rabatt?](/de/benutzung/gebuehren).
