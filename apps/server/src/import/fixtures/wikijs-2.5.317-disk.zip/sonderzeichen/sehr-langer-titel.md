---
title: Richtlinie für die Aussonderung, Bewertung und Weitergabe von beschädigten oder veralteten Medien an gemeinnützige Einrichtungen in Eichenau und Umgebung
description: Sehr langer Titel (~150 Zeichen)
published: true
date: 2026-10-28T21:10:58.901Z
tags: richtlinie
editor: markdown
dateCreated: 2026-10-28T21:10:58.179Z
---

# Aussonderung

Siehe [Bestand](/de/bestand) – lange Titel müssen gekürzt werden.
