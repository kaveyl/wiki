---
title: Zitat: 'Lesen ist Abenteuer' – "Leitbild"
description: Anführungszeichen beider Art und Doppelpunkt
published: true
date: 2026-10-28T21:10:56.228Z
tags: leitbild
editor: markdown
dateCreated: 2026-10-28T21:10:55.544Z
---

# Leitbild

> „Lesen ist Abenteuer im Kopf.“
