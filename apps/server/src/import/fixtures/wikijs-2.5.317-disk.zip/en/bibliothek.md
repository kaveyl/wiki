---
title: Library (same path as German page)
description: 
published: true
date: 2026-10-28T21:11:08.262Z
tags: about
editor: markdown
dateCreated: 2026-10-28T21:11:07.555Z
---

# Library

Same path as the German page `bibliothek` – lives in `en/bibliothek.md`.
