---
title: Opening Hours
description: 
published: true
date: 2026-10-28T21:11:04.239Z
tags: service
editor: markdown
dateCreated: 2026-10-28T21:11:03.537Z
---

# Opening hours

Tuesday to Friday 10:00–18:00. Details in German: [Öffnungszeiten](/de/bibliothek/öffnungszeiten).
