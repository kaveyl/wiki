---
title: About the Library
description: Relative link becomes a child path
published: true
date: 2026-10-28T21:11:02.913Z
tags: about
editor: markdown
dateCreated: 2026-10-28T21:11:02.188Z
---

# About the library

Founded in 1952. See the German [history page](/de/bibliothek/geschichte) and [opening hours](opening-hours).
