---
title: Renewal
description: 
published: true
date: 2026-10-28T21:11:05.590Z
tags: borrowing
editor: markdown
dateCreated: 2026-10-28T21:11:04.873Z
---

# Renewal

Renew twice online. Link without locale: [fees](/benutzung/gebuehren) (resolves to /en/benutzung/gebuehren – missing).
