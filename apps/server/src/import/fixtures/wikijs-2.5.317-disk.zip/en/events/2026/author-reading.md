---
title: Author Reading: Crime Stories
description: Colon in English title
published: true
date: 2026-10-28T21:11:06.925Z
tags: reading, events
editor: markdown
dateCreated: 2026-10-28T21:11:06.223Z
---

# Author reading

German version: [Herbstlesung](/de/veranstaltungen/2026/lesungen/herbst-lesung).

![Bookworm](/bilder/veranstaltungen/2026/bücherwurm.gif)
