---
title: Home
description: English start page
published: true
date: 2026-10-28T21:11:04.711Z
tags: start
editor: markdown
dateCreated: 2026-10-28T21:11:00.817Z
---

# Welcome to the Eichenau Public Library wiki

- [About the library](/en/about/library)
- [Opening hours](/en/about/opening-hours)
- [Deutsche Startseite](/de/home)
