---
title: Bestand
description: 
published: true
date: 2026-10-28T21:10:05.551Z
tags: bestand
editor: markdown
dateCreated: 2026-10-28T21:09:53.599Z
---

# Bestand

Rund 38.000 Medien. Siehe [Systematik](/de/bestand/systematik), [Medienarten](medienarten) und
[Neuerwerbungen Oktober](/de/bestand/neuerwerbungen/2026/oktober).
