---
title: Veranstaltungen
description: Mermaid und Tag-Link
published: true
date: 2026-10-28T21:10:29.789Z
tags: veranstaltungen
editor: markdown
dateCreated: 2026-10-28T21:10:19.207Z
---

# Veranstaltungen

```mermaid
gantt
  title Programm Herbst 2026
  dateFormat YYYY-MM-DD
  section Lesungen
  Herbstlesung :a1, 2026-10-15, 1d
  Krimi-Nacht  :a2, 2026-11-06, 1d
  section Kinder
  Vorlesestunde :k1, 2026-10-07, 60d
```

Alle Termine mit Tag: [lesung](/t/lesung). Archiv: [Sommerfest 2024](/de/veranstaltungen/Archiv/Sommerfest-2024).
