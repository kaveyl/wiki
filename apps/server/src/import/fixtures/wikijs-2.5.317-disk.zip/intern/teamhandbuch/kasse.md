---
title: Kasse & Abrechnung
description: 
published: true
date: 2026-10-28T21:10:36.109Z
tags: intern, kasse
editor: markdown
dateCreated: 2026-10-28T21:10:35.420Z
---

# Kasse

Tagesabschluss bis 18:15 Uhr.

```python
def tagesabschluss(einnahmen: list[float]) -> float:
    return round(sum(einnahmen), 2)
```

> Wechselgeld nie über 200 € im Fach.
{.is-warning}
