---
title: Notfallplan
description: 
published: true
date: 2026-10-28T21:10:37.429Z
tags: intern, sicherheit
editor: markdown
dateCreated: 2026-10-28T21:10:36.737Z
---

# Notfallplan

## Erste Schritte

1. Ruhe bewahren.
2. Notruf **112**.
3. Gebäude über die markierten Wege räumen.

> Sammelpunkt ist der Marktplatz.
{.is-danger}

## Kontakte

Hausmeister: Durchwahl 17.
