---
title: Dienstplan
description: 
published: true
date: 2026-10-28T21:10:34.791Z
tags: intern, dienstplan
editor: markdown
dateCreated: 2026-10-28T21:10:34.061Z
---

# Dienstplan

## Wochenplan

| | Mo | Di | Mi | Do | Fr | Sa |
|---|---|---|---|---|---|---|
| Früh | – | A | B | A | B | C |
| Spät | – | C | – | B | A | – |

Tausch nur nach Absprache.
