---
title: WLAN für Gäste
description: Vier Ebenen
published: true
date: 2026-10-28T21:10:41.467Z
tags: it, wlan
editor: markdown
dateCreated: 2026-10-28T21:10:40.725Z
---

# WLAN

SSID `Bibliothek-Gast`, kein Passwort, Nutzungsbedingungen auf der [Startseite](/de/home).

```bash
nmcli dev wifi connect "Bibliothek-Gast"
```
