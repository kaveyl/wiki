---
title: Katalog (OPAC)
description: 
published: true
date: 2026-10-28T21:10:40.092Z
tags: it, katalog
editor: markdown
dateCreated: 2026-10-28T21:10:39.367Z
---

# Katalog

Der OPAC läuft unter <https://katalog.example.org>. Benutzerkonto siehe [Ausweis](/benutzung/ausweis).
