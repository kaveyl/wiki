---
title: Drucker & Kopierer
description: Zweiter Pfadteil ist „it“ (zwei Buchstaben)
published: true
date: 2026-10-28T21:10:38.747Z
tags: it
editor: markdown
dateCreated: 2026-10-28T21:10:38.041Z
---

# Drucker

Treiber unter `\\server\drucker`. Fehler `E-42` = Papierstau.
