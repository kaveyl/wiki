---
title: Teamsitzung 09/2026
description: Relativer Link als Kindseite – führt ins Leere
published: true
date: 2026-10-28T21:10:42.810Z
tags: intern, protokoll
editor: markdown
dateCreated: 2026-10-28T21:10:42.086Z
---

# Teamsitzung September

- [x] Herbstprogramm beschlossen
- [ ] Flyer drucken

Nächste Sitzung: [Oktober](teamsitzung-2026-10)
