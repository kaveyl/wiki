---
title: Teamsitzung 10/2026
description: 
published: true
date: 2026-10-28T21:10:44.108Z
tags: intern, protokoll
editor: markdown
dateCreated: 2026-10-28T21:10:43.406Z
---

# Teamsitzung Oktober

- [x] Flyer gedruckt
- [ ] Inventur planen

Vorige Sitzung: [September](../teamsitzung-2026-09)
