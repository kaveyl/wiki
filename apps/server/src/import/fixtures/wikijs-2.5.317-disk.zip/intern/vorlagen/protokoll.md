---
title: Vorlage: Protokoll
description: Titel mit Doppelpunkt, Tag mit Doppelpunkt
published: true
date: 2026-10-28T21:10:45.450Z
tags: vorlage, status:entwurf
editor: markdown
dateCreated: 2026-10-28T21:10:44.722Z
---

# Protokoll {Datum}

**Anwesend:**

**Themen:**

1.
