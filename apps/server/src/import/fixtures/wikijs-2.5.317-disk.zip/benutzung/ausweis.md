---
title: Bibliotheksausweis
description: 
published: true
date: 2026-10-28T21:10:10.433Z
tags: benutzung, ausweis
editor: markdown
dateCreated: 2026-10-28T21:10:09.722Z
---

# Bibliotheksausweis

Den Ausweis gibt es gegen Vorlage eines Lichtbildausweises.

## Passwort vergessen

Das Team setzt es an der Theke zurück. Siehe [Gebühren](../gebuehren) für Ersatzausweise.
