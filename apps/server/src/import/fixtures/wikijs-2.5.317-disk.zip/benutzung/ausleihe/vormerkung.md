---
title: Vormerkung
description: 
published: true
date: 2026-10-28T21:10:15.878Z
tags: ausleihe
editor: markdown
dateCreated: 2026-10-28T21:10:15.203Z
---

# Vormerkung

Vormerkungen kosten 1 €. Abholung innerhalb von 7 Tagen.
