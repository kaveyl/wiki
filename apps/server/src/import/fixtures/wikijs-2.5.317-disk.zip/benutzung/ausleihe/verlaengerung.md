---
title: Verlängerung
description: 
published: true
date: 2026-10-28T21:10:16.354Z
tags: ausleihe
editor: markdown
dateCreated: 2026-10-28T21:10:13.834Z
---

# Verlängerung

Zweimal online verlängern, danach an der Theke. Vorgemerkte Medien lassen sich nicht verlängern
(siehe [Vormerkung](/de/benutzung/ausleihe/vormerkung)).
