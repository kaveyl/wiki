---
title: Fernleihe
description: 
published: true
date: 2026-10-28T21:10:17.219Z
tags: ausleihe, fernleihe
editor: markdown
dateCreated: 2026-10-28T21:10:16.523Z
---

# Fernleihe

Bestellung über das [Fernleihportal](https://example.org/fernleihe). Gebühr 2 € je Bestellung.
