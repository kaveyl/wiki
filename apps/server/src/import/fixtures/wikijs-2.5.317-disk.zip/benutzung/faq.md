---
title: Häufige Fragen (FAQ)
description: Tabs, Callouts, sup/sub
published: true
date: 2026-10-28T21:10:18.572Z
tags: benutzung, faq
editor: markdown
dateCreated: 2026-10-28T21:10:17.820Z
---

# Häufige Fragen

# Tabs {.tabset}
## Ausweis
Wie lange gilt der Ausweis? **Ein Jahr.**
## Ausleihe
Wie viele Medien darf ich leihen? Bis zu 30.
## Digital
Wie funktioniert die [Onleihe](/de/bestand/medienarten/digitale-medien/onleihe)?

# Hinweise

> Bitte keine Medien in den Briefkasten werfen.
{.is-danger}

> **Tipp:** Die Rückgabebox ist rund um die Uhr geöffnet.
{.is-success}

Wasser ist H~2~O, der 19^te^ Leseclub startet bald. Tastatur: <kbd>Strg</kbd> + <kbd>F</kbd>.
