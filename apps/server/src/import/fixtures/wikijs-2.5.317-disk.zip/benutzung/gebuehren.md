---
title: Gebühren & Entgelte
description: Gebühren mit Mathe und & im Titel
published: true
date: 2026-10-28T21:10:11.839Z
tags: benutzung, gebühren
editor: markdown
dateCreated: 2026-10-28T21:10:11.077Z
---

# Gebühren & Entgelte

| Leistung | Preis |
|---|---:|
| Jahresausweis Erwachsene | 15,00 € |
| Kinder & Jugendliche | 0,00 € |
| Ersatzausweis | 3,00 € |
| Säumnisgebühr je Medium/Woche | 0,50 € |

Gebühren berechnen sich nach $g = n \cdot w \cdot 0{,}5$ €.

$$
\sum_{i=1}^{n} g_i \le 10
$$

*[ASB]: Allgemeine Systematik für Öffentliche Bibliotheken
