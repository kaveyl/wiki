---
title: Neuerwerbungen Oktober 2026
description: Aufgabenliste
published: true
date: 2026-10-28T21:10:05.083Z
tags: neuerwerbungen, 2026
editor: markdown
dateCreated: 2026-10-28T21:10:04.367Z
---

# Neuerwerbungen Oktober 2026

- [x] Bestellung ausgelöst
- [x] Lieferung eingetroffen
- [ ] Eingearbeitet
- [ ] Im Katalog sichtbar

Vormonat: [September](../september)
