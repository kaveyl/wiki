---
title: Neuerwerbungen September 2026
description: 
published: true
date: 2026-10-28T21:10:06.422Z
tags: neuerwerbungen, 2026
editor: markdown
dateCreated: 2026-10-28T21:10:05.718Z
---

# Neuerwerbungen September 2026

- [x] Alles eingearbeitet

Nächster Monat: [Oktober](/de/bestand/neuerwerbungen/2026/oktober)
