---
title: Systematik (ASB-Auszug)
description: 
published: true
date: 2026-10-28T21:10:03.729Z
tags: bestand, systematik
editor: markdown
dateCreated: 2026-10-28T21:10:02.988Z
---

# Systematik

## Sachbücher

| Gruppe | Bedeutung | Beispiel |
|---|---|---|
| A | Allgemeines | Lexika |
| G | Geschichte | Ortschroniken |
| T | Technik | Fahrradreparatur |
| V | Sport | Wandern |

## Belletristik

Romane nach Autor, Krimis mit rotem Punkt.

```json
{ "signatur": "G 123 Eic", "standort": "Hauptstelle", "ausleihbar": true }
```
