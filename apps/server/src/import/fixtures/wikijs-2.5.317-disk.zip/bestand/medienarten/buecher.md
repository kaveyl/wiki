---
title: Bücher
description: 
published: true
date: 2026-10-28T21:10:04.200Z
tags: bestand, bücher
editor: markdown
dateCreated: 2026-10-28T21:09:56.275Z
---

# Bücher

Sachbücher nach [Systematik](/de/bestand/systematik#sachbücher), Romane alphabetisch.

```sql
SELECT titel, signatur FROM medien WHERE art = 'Buch' AND jahr >= 2025;
```
