---
title: Zeitschriften
description: 
published: true
date: 2026-10-28T21:09:58.350Z
tags: bestand, zeitschriften
editor: markdown
dateCreated: 2026-10-28T21:09:57.618Z
---

# Zeitschriften

Wir führen 42 Abos. Die aktuelle Ausgabe ist nicht ausleihbar.

Fußnote zum Umlauf[^1].

[^1]: Ältere Hefte dürfen eine Woche ausgeliehen werden.
