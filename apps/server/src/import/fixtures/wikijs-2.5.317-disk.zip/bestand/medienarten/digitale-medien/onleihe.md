---
title: Onleihe – E-Books leihen
description: 
published: true
date: 2026-10-28T21:10:10.909Z
tags: digital, onleihe
editor: markdown
dateCreated: 2026-10-28T21:10:00.326Z
---

# Onleihe

1. Ausweisnummer und Passwort bereithalten.
2. App installieren.
3. Titel auswählen und ausleihen.

> Die Onleihe ist rund um die Uhr erreichbar. :tada:
{.is-success}

Hilfe zur Anmeldung: [Ausweis](/de/benutzung/ausweis#passwort-vergessen).
