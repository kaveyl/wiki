---
title: Vorlesestunde für Kinder ab 4
description: PlantUML
published: true
date: 2026-10-28T21:10:23.980Z
tags: kinder, leseförderung
editor: markdown
dateCreated: 2026-10-28T21:10:23.265Z
---

# Vorlesestunde

Jeden Mittwoch um 15 Uhr in der [Kinderbibliothek](/de/bibliothek/standorte/hauptstelle/raeume/kinderbibliothek).

```plantuml
@startuml
Kind -> Bibliothek: kommt zur Vorlesestunde
Bibliothek -> Kind: liest vor
@enduml
```
