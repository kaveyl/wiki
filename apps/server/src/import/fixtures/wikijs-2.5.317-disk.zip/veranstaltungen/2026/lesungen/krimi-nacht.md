---
title: "Mord im Magazin" – Krimi-Nacht
description: Titel beginnt mit Anführungszeichen
published: true
date: 2026-10-28T21:10:22.657Z
tags: lesung, krimi
editor: markdown
dateCreated: 2026-10-28T21:10:21.959Z
---

# Krimi-Nacht

Taschenlampen-Führung durch das Magazin. Plan: [Leseplan 2026 (PDF)](/dokumente/leseplan_2026.pdf).
