---
title: Übersicht
description: Gleicher letzter Teil wie bei den Neuerwerbungen
published: true
date: 2026-10-28T21:10:30.688Z
tags: veranstaltungen
editor: markdown
dateCreated: 2026-10-28T21:10:29.957Z
---

# Oktober 2026

- [Herbstlesung](/de/veranstaltungen/2026/lesungen/herbst-lesung)
- [Vorlesestunde](/de/veranstaltungen/2026/kinder/vorlesestunde)
