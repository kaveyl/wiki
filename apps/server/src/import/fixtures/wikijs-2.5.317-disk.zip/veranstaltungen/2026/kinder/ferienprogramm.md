---
title: #Ferienprogramm 2026
description: Titel beginnt mit #, draw.io-Diagramm
published: true
date: 2026-10-28T21:10:25.342Z
tags: kinder, ferien
editor: markdown
dateCreated: 2026-10-28T21:10:24.622Z
---

# Ferienprogramm

```diagram
PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjAiIGhlaWdodD0iNDAiPjxyZWN0IHdpZHRoPSIxMjAiIGhlaWdodD0iNDAiIGZpbGw9IiNkZGVlZmYiLz48dGV4dCB4PSIxMCIgeT0iMjUiPkF1c2xlaWhlPC90ZXh0Pjwvc3ZnPg==
```

Anmeldung ab 1. Juni.
