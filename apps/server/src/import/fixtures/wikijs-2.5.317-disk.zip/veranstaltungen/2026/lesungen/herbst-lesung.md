---
title: Herbstlesung: Krimis aus der Region
description: Titel mit Doppelpunkt: YAML-Risiko
published: true
date: 2026-10-28T21:11:07.388Z
tags: veranstaltungen, lesung, krimi
editor: markdown
dateCreated: 2026-10-28T21:10:20.573Z
---

# Herbstlesung

Am 15. Oktober liest die (erfundene) Autorin *Mara Muster* aus ihrem Krimi.

![Bücherwurm](/bilder/veranstaltungen/2026/bücherwurm.gif)

Eintritt frei, Anmeldung über [info@eichenau.example](mailto:info@eichenau.example).
English version: [Author reading](/en/events/2026/author-reading).
