---
title: Sommerfest 2024
description: Pfad mit Großbuchstaben
published: true
date: 2026-10-28T21:10:29.319Z
tags: archiv
editor: markdown
dateCreated: 2026-10-28T21:10:28.599Z
---

# Sommerfest 2024

Pfad mit Großbuchstaben. Zurück zu den [Veranstaltungen](/de/veranstaltungen).
