---
title: Rückblick 2025
description: 
published: true
date: 2026-10-28T21:10:27.976Z
tags: rückblick
editor: markdown
dateCreated: 2026-10-28T21:10:27.264Z
---

# Rückblick 2025

![Ausflug](/bilder/ausflug_eichenauer_höhe.jpg){.align-center}

Der Ausflug auf die Eichenauer Höhe war ein Erfolg.
