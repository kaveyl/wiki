---
title: Startseite
description: Einstieg ins Wiki der Stadtbibliothek
published: true
date: 2026-10-28T21:11:02.022Z
tags: start, übersicht
editor: markdown
dateCreated: 2026-10-28T21:09:36.021Z
---

# Willkommen im Wiki der Stadtbibliothek Eichenau

![Logo](/logo_stadtbibliothek.svg =120x)

Dieses Wiki sammelt alles, was das Team der **Stadtbibliothek Eichenau** wissen muss. :books:

- [Über die Bibliothek *Geschichte, Team, Standorte*](/de/bibliothek)
- [Bestand *Medienarten und Systematik*](/de/bestand)
- [Benutzung *Ausweis, Gebühren, Ausleihe*](/de/benutzung)
- [Veranstaltungen *Lesungen und Kinderprogramm*](/de/veranstaltungen)
{.links-list}

## Schnellzugriff

| Bereich | Seite |
|---|---|
| Öffnungszeiten | [Öffnungszeiten](/de/bibliothek/öffnungszeiten) |
| Gebühren | [Gebühren & Entgelte](/benutzung/gebuehren) |
| Notfall | [Notfallplan](/de/intern/teamhandbuch/notfall#erste-schritte) |
| English | [Library in English](/en/home) |

> Neu hier? Lies zuerst das [Teamhandbuch](/de/intern/teamhandbuch).
{.is-info}

Kontakt: [info@eichenau.example](mailto:info@eichenau.example) · Telefon [089 000 000](tel:+4989000000)
