---
title: Räume
description: 
published: true
date: 2026-10-28T21:09:50.751Z
tags: räume
editor: markdown
dateCreated: 2026-10-28T21:09:46.835Z
---

# Räume der Hauptstelle

| Raum | Plätze | Seite |
|---|---|---|
| Lesesaal | 40 | [Lesesaal](/de/bibliothek/standorte/hauptstelle/raeume/lesesaal) |
| Kinderbibliothek | 25 | [Kinderbibliothek](/de/bibliothek/standorte/hauptstelle/raeume/kinderbibliothek) |
| Gruppenraum | 12 | [nicht angelegt](/de/bibliothek/standorte/hauptstelle/raeume/gruppenraum) |
