---
title: Hauptstelle am Markt
description: 
published: true
date: 2026-10-28T21:09:49.394Z
tags: standorte, hauptstelle
editor: markdown
dateCreated: 2026-10-28T21:09:44.152Z
---

# Hauptstelle am Markt

Adresse: Marktplatz 1, 82223 Eichenau (erfunden).

- [Anfahrt](anfahrt)
- [Räume](raeume)
- [Lesesaal](raeume/lesesaal)
- [Zur Zweigstelle](../zweigstelle-nord)
