---
title: Anfahrt
description: Gleicher Name wie in der Hauptstelle
published: true
date: 2026-10-28T21:09:52.970Z
tags: anfahrt
editor: markdown
dateCreated: 2026-10-28T21:09:52.257Z
---

# Anfahrt zur Zweigstelle Nord

Bus 840 bis „Bürgerhaus“. Fahrradständer vor dem Eingang.
