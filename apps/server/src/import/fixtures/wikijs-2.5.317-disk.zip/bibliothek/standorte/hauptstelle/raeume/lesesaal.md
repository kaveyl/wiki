---
title: Lesesaal
description: Fünf Ebenen tief
published: true
date: 2026-10-28T21:10:41.927Z
tags: räume, lesesaal
editor: markdown
dateCreated: 2026-10-28T21:09:48.220Z
---

# Lesesaal

![Blick in den Lesesaal](/bilder/lesesaal_übersicht.png)

Ruhezone – bitte Telefone lautlos stellen. Steckdosen an jedem Platz.

Siehe auch [Kinderbibliothek](../kinderbibliothek) und [WLAN](/de/intern/it/netzwerk/wlan).
