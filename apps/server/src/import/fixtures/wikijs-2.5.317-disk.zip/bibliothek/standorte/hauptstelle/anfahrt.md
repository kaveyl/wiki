---
title: Anfahrt
description: Gleicher Name wie in der Zweigstelle
published: true
date: 2026-10-28T21:09:46.210Z
tags: anfahrt
editor: markdown
dateCreated: 2026-10-28T21:09:45.481Z
---

# Anfahrt zur Hauptstelle

- S-Bahn bis Eichenau, dann 5 Minuten zu Fuß.
- Parkplätze hinter dem Rathaus.

Zurück zur [Hauptstelle](/de/bibliothek/standorte/hauptstelle).
