---
title: Öffnungszeiten & Schließtage
description: Pfad mit Umlaut, eigene Anker-ID
published: true
date: 2026-10-28T21:09:42.154Z
tags: öffnungszeiten, service
editor: markdown
dateCreated: 2026-10-28T21:09:41.423Z
---

# Öffnungszeiten

## Öffnungszeiten im Winter

| Tag | Hauptstelle | Zweigstelle Nord |
|:---|:---:|---:|
| Montag | geschlossen | geschlossen |
| Dienstag | 10–18 Uhr | 14–18 Uhr |
| Mittwoch | 10–13 Uhr | — |
| Donnerstag | 10–19 Uhr | 14–19 Uhr |
| Freitag | 10–18 Uhr | 14–18 Uhr |
| Samstag | 10–13 Uhr | — |

## Öffnungszeiten im Sommer

In den Sommerferien gelten verkürzte Zeiten (siehe [oben](#öffnungszeiten-im-winter)).

## Schließtage 2026 {#schliesstage}

1. 24.12. bis 1.1.
2. Faschingsdienstag
3. Inventur im August

> Abweichungen stehen auf der [Startseite](/de/home).
{.is-warning}
