---
tags: hütte, südtirol
---
# Hütte 6: Südtiroler Haus
Lage: Südtirol, 1422 m.

Vorher: [Hütte 5](http://127.0.0.1:8097/xikqCGgBRXWKD8H56Naanw)

- [ ] reservieren
- [ ] Beitrag bezahlt
