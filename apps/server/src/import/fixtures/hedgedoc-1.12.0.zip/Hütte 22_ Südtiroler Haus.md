---
tags: hütte, südtirol
---
# Hütte 22: Südtiroler Haus
Lage: Südtirol, 2014 m.

Vorher: [Hütte 21](http://127.0.0.1:8097/KOZ5f93RRCy1N8ziNL2eNg)

- [ ] reservieren
- [ ] Beitrag bezahlt
