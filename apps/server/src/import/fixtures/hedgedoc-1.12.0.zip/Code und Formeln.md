# Code und Formeln
```javascript=
function hoehenmeter(a, b) {
  return Math.abs(b - a);
}
```

```python
print("Grüß Gott")
```

Inline-Mathe: $E = mc^2$ und Block:

$$
\sum_{i=1}^{n} h_i = H
$$

```mermaid
graph TD
  A[Parkplatz] --> B(Hütte)
  B --> C{Gipfel?}
```

```sequence
Anna->Jörg: Abmarsch?
Jörg-->Anna: 7 Uhr
```

```graphviz
digraph { Hütte -> Gipfel }
```
