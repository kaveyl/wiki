---
tags: hütte, kärnten
---
# Hütte 26: Kärntener Haus
Lage: Kärnten, 2162 m.

Vorher: [Hütte 25](http://127.0.0.1:8097/t714rnJsTLKILJl9qonWsQ)

- [ ] reservieren
- [ ] Beitrag bezahlt
