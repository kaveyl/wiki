---
tags: hütte, graubünden
---
# Hütte 31: Graubündener Haus
Lage: Graubünden, 2347 m.

Vorher: [Hütte 30](http://127.0.0.1:8097/NTPvN0xESl6UKFrAer4k5Q)

- [ ] reservieren
- [x] Beitrag bezahlt
