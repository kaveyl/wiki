# Formatierungen
==markiert==, ^hoch^, ~tief~, ++eingefügt++, ~~gestrichen~~, :smile: :mountain:

Fußnote[^1] und noch eine[^lang].

[^1]: Erste Fußnote.
[^lang]: Eine längere Fußnote mit **fett**.

> Zitat
> > verschachtelt

Abkürzung: *[HTML]: Hyper Text Markup Language

Term
: Definition
