---
tags: hütte, tirol
---
# Hütte 8: Tiroler Haus
Lage: Tirol, 1496 m.

Vorher: [Hütte 7](http://127.0.0.1:8097/-vVRMzGQQL-Ia14-UI2hig)

- [ ] reservieren
- [ ] Beitrag bezahlt
