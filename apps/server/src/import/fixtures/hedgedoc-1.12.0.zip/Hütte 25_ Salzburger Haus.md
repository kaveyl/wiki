---
tags: hütte, salzburg
---
# Hütte 25: Salzburger Haus
Lage: Salzburg, 2125 m.

Vorher: [Hütte 24](http://127.0.0.1:8097/_GqLC2lnSS21Dbpli8wNJg)

- [ ] reservieren
- [x] Beitrag bezahlt
