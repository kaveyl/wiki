# HTML im Text
<details><summary>Mehr</summary>Versteckter Text</details>

<span style="color:red">rot</span>

<script>alert('nicht ausführen')</script>

<img src="x" onerror="alert(1)">
