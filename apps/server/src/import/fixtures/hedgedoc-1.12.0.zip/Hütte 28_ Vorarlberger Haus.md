---
tags: hütte, vorarlberg
---
# Hütte 28: Vorarlberger Haus
Lage: Vorarlberg, 2236 m.

Vorher: [Hütte 27](http://127.0.0.1:8097/yArNbjxORBmPHOAXiUTudA)

- [ ] reservieren
- [ ] Beitrag bezahlt
