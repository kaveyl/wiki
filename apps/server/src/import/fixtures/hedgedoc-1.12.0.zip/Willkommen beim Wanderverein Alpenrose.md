# Willkommen beim Wanderverein Alpenrose
[TOC]

## Über uns
Wir wandern seit 1987. ![Logo](http://127.0.0.1:8097/uploads/aa975579-d66f-4499-89fd-59c479948b53.svg)

:::info
Neue Mitglieder sind willkommen – siehe Abschnitt *Beitritt*.
:::

## Beitritt
Formular folgt.
