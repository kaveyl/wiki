---
tags: hütte, salzburg
---
# Hütte 17: Salzburger Haus
Lage: Salzburg, 1829 m.

Vorher: [Hütte 16](http://127.0.0.1:8097/Z2hi-DR9SRqATnKii_z8rQ)

- [ ] reservieren
- [x] Beitrag bezahlt
