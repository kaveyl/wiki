---
tags: hütte, südtirol
---
# Hütte 38: Südtiroler Haus
Lage: Südtirol, 2606 m.

Vorher: [Hütte 37](http://127.0.0.1:8097/gugZzYF1Rx2XDvfKGfyRwQ)

- [ ] reservieren
- [ ] Beitrag bezahlt
