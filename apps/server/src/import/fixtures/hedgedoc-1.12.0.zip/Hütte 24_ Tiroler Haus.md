---
tags: hütte, tirol
---
# Hütte 24: Tiroler Haus
Lage: Tirol, 2088 m.

Vorher: [Hütte 23](http://127.0.0.1:8097/EeXurYi_T96DnOWL-oFnXA)

- [ ] reservieren
- [ ] Beitrag bezahlt
