---
tags: hütte, bayern
---
# Hütte 29: Bayerner Haus
Lage: Bayern, 2273 m.

Vorher: [Hütte 28](http://127.0.0.1:8097/YDKzlO3ZSyqFUoTADo0jQQ)

- [ ] reservieren
- [x] Beitrag bezahlt
