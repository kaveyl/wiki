---
tags: hütte, graubünden
---
# Hütte 23: Graubündener Haus
Lage: Graubünden, 2051 m.

Vorher: [Hütte 22](http://127.0.0.1:8097/jWdh2sWBSEOrTtIRAxsmug)

- [ ] reservieren
- [x] Beitrag bezahlt
