---
tags: hütte, südtirol
---
# Hütte 14: Südtiroler Haus
Lage: Südtirol, 1718 m.

Vorher: [Hütte 13](http://127.0.0.1:8097/Pg3VBaBnRUugTiI4itzXGA)

- [ ] reservieren
- [ ] Beitrag bezahlt
