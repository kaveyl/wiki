---
tags: hütte, steiermark
---
# Hütte 35: Steiermarker Haus
Lage: Steiermark, 2495 m.

Vorher: [Hütte 34](http://127.0.0.1:8097/UBeXnoGdTH68ZpV_1e_IXQ)

- [ ] reservieren
- [x] Beitrag bezahlt
