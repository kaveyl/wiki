---
title: Jahreshauptversammlung (Folien)
type: slide
slideOptions:
  theme: solarized
  transition: fade
tags:
  - versammlung
  - folien
---
# Jahreshauptversammlung 2026

---

## Tagesordnung
1. Bericht des Vorstands
2. Kassenbericht
3. Wahlen

---

## Kasse
- Einnahmen: 4.210 €
- Ausgaben: 3.877 €

Note: Sprechernotiz – nicht vorlesen.
