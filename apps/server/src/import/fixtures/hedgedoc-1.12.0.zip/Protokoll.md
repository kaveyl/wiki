# Protokoll
Sitzung Nummer 1. Anwesend: 6 Mitglieder.

Siehe [Touren](http://127.0.0.1:8097/-cXIvBfUQMiTBEoVgFJXGA).
