---
tags: hütte, bayern
---
# Hütte 13: Bayerner Haus
Lage: Bayern, 1681 m.

Vorher: [Hütte 12](http://127.0.0.1:8097/jatC3kILRxC6HrJKqfAlaQ)

- [ ] reservieren
- [x] Beitrag bezahlt
