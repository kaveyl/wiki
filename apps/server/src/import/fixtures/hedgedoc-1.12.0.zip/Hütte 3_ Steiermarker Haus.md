---
tags: hütte, steiermark
---
# Hütte 3: Steiermarker Haus
Lage: Steiermark, 1311 m.

Vorher: [Hütte 2](http://127.0.0.1:8097/lSE3HciyStK9dxfL9yjBUg)

- [ ] reservieren
- [x] Beitrag bezahlt
