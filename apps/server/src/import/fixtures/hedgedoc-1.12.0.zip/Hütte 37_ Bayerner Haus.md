---
tags: hütte, bayern
---
# Hütte 37: Bayerner Haus
Lage: Bayern, 2569 m.

Vorher: [Hütte 36](http://127.0.0.1:8097/vh-urA5nRVqyHiTW_IReUg)

- [ ] reservieren
- [x] Beitrag bezahlt
