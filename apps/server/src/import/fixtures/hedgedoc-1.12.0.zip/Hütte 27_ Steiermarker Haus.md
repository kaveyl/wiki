---
tags: hütte, steiermark
---
# Hütte 27: Steiermarker Haus
Lage: Steiermark, 2199 m.

Vorher: [Hütte 26](http://127.0.0.1:8097/ZDUFGeGfTNWISgBffocoNQ)

- [ ] reservieren
- [x] Beitrag bezahlt
