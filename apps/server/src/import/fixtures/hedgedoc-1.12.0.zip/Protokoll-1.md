# Protokoll
Sitzung Nummer 2. Anwesend: 7 Mitglieder.

Siehe [Touren](http://127.0.0.1:8097/-cXIvBfUQMiTBEoVgFJXGA).
