---
tags: hütte, steiermark
---
# Hütte 19: Steiermarker Haus
Lage: Steiermark, 1903 m.

Vorher: [Hütte 18](http://127.0.0.1:8097/tKavhLVyRJCIaFHbm-rMcQ)

- [ ] reservieren
- [x] Beitrag bezahlt
