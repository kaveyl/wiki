---
tags: hütte, salzburg
---
# Hütte 9: Salzburger Haus
Lage: Salzburg, 1533 m.

Vorher: [Hütte 8](http://127.0.0.1:8097/SIFYppLmRh-u5QA7GOF4Yg)

- [ ] reservieren
- [x] Beitrag bezahlt
