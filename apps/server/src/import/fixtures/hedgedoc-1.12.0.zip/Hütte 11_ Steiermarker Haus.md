---
tags: hütte, steiermark
---
# Hütte 11: Steiermarker Haus
Lage: Steiermark, 1607 m.

Vorher: [Hütte 10](http://127.0.0.1:8097/zOq9w3wQThaULmudyeUoDw)

- [ ] reservieren
- [x] Beitrag bezahlt
