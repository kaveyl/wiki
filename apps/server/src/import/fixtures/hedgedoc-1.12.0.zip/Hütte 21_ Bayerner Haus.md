---
tags: hütte, bayern
---
# Hütte 21: Bayerner Haus
Lage: Bayern, 1977 m.

Vorher: [Hütte 20](http://127.0.0.1:8097/bLXZ7mySTASqqM-u5cj_zw)

- [ ] reservieren
- [x] Beitrag bezahlt
