---
title: Touren 2026 – Alpen
tags: touren, alpen, 2026
description: Alle Touren im Hochgebirge
---
# Touren 2026 – Alpen

| Datum | Ziel | Höhe | Leitung |
|---|---|---:|---|
| 12.06. | Großglockner-Blick | 2.571 m | Jörg |
| 03.07. | Dachstein Südwand | 2.995 m | Anna-Lena |
| 21.08. | Zugspitze über Höllental | 2.962 m | Ömer |

![Gipfelfoto](http://127.0.0.1:8097/uploads/dbb611a4-f519-4bb5-a5b8-380412018b00.jpg)

Zurück zur [Startseite](http://127.0.0.1:8097/uNJTyaP-QUSKM6DImyayIA) oder direkt zum [Beitritt](/uNJTyaP-QUSKM6DImyayIA#Beitritt).
