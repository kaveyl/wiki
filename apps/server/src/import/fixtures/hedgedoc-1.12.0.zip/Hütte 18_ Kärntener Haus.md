---
tags: hütte, kärnten
---
# Hütte 18: Kärntener Haus
Lage: Kärnten, 1866 m.

Vorher: [Hütte 17](http://127.0.0.1:8097/ru9UrNVvRRue54g5pTZ3sQ)

- [ ] reservieren
- [ ] Beitrag bezahlt
