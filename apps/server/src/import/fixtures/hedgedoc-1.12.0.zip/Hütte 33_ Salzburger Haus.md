---
tags: hütte, salzburg
---
# Hütte 33: Salzburger Haus
Lage: Salzburg, 2421 m.

Vorher: [Hütte 32](http://127.0.0.1:8097/h6vZtJ8LTQO9Axzwt-7oYg)

- [ ] reservieren
- [x] Beitrag bezahlt
