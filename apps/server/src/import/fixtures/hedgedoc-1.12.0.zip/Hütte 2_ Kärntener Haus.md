---
tags: hütte, kärnten
---
# Hütte 2: Kärntener Haus
Lage: Kärnten, 1274 m.

Vorher: [Hütte 1](http://127.0.0.1:8097/sGDUebjoT2GxEfavVFwrNQ)

- [ ] reservieren
- [ ] Beitrag bezahlt
