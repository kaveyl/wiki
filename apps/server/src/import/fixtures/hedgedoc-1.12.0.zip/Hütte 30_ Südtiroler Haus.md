---
tags: hütte, südtirol
---
# Hütte 30: Südtiroler Haus
Lage: Südtirol, 2310 m.

Vorher: [Hütte 29](http://127.0.0.1:8097/AQ15aypqRE219jEGySA80Q)

- [ ] reservieren
- [ ] Beitrag bezahlt
