---
tags: hütte, graubünden
---
# Hütte 7: Graubündener Haus
Lage: Graubünden, 1459 m.

Vorher: [Hütte 6](http://127.0.0.1:8097/J16-NAlzRzKZVZCh5natpw)

- [ ] reservieren
- [x] Beitrag bezahlt
