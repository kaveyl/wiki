# Packliste Hüttentour
- [x] Schlafsack (Hüttenschlafsack!)
- [x] Stirnlampe
- [ ] Erste-Hilfe-Set
  - [ ] Blasenpflaster
  - [x] Rettungsdecke
- [ ] Bargeld für die Hütte
