# Hinweisboxen
:::success
Tour erfolgreich abgeschlossen!
:::

:::warning
Steinschlaggefahr im oberen Teil.
:::

:::danger
Bei Gewitter sofort umkehren.
:::

:::spoiler Ausrüstung (aufklappen)
- Helm
- Klettersteigset
:::
