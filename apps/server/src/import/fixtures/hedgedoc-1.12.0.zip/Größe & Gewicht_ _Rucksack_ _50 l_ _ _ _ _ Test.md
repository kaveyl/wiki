# Größe & Gewicht? <Rucksack> "50 l" | * : \ Test
Sonderzeichen im Titel.
