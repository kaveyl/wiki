---
tags: hütte, tirol
---
# Hütte 32: Tiroler Haus
Lage: Tirol, 2384 m.

Vorher: [Hütte 31](http://127.0.0.1:8097/Ff33EUmERZuKdk9HADN07w)

- [ ] reservieren
- [ ] Beitrag bezahlt
