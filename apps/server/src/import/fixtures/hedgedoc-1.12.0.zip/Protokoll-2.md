# Protokoll
Sitzung Nummer 3. Anwesend: 8 Mitglieder.

Siehe [Touren](http://127.0.0.1:8097/-cXIvBfUQMiTBEoVgFJXGA).
