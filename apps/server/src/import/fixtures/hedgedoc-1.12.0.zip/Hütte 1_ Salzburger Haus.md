---
tags: hütte, salzburg
---
# Hütte 1: Salzburger Haus
Lage: Salzburg, 1237 m.

Vorher: [Hütte 0](http://127.0.0.1:8097/AOXT7zJFRpWvXGE3H1enjQ)

- [ ] reservieren
- [x] Beitrag bezahlt
