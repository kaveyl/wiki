---
tags: hütte, bayern
---
# Hütte 5: Bayerner Haus
Lage: Bayern, 1385 m.

Vorher: [Hütte 4](http://127.0.0.1:8097/rV52TKZKQLyx0o5e_rSUTg)

- [ ] reservieren
- [x] Beitrag bezahlt
