---
tags: hütte, kärnten
---
# Hütte 34: Kärntener Haus
Lage: Kärnten, 2458 m.

Vorher: [Hütte 33](http://127.0.0.1:8097/gcP1ZqeSSHms7Yfg6cN4Rw)

- [ ] reservieren
- [ ] Beitrag bezahlt
