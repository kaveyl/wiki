---
tags: hütte, kärnten
---
# Hütte 10: Kärntener Haus
Lage: Kärnten, 1570 m.

Vorher: [Hütte 9](http://127.0.0.1:8097/AqB8De--TMyAu1ja5_J4wg)

- [ ] reservieren
- [ ] Beitrag bezahlt
