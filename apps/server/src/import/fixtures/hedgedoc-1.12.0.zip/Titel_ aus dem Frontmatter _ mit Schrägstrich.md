---
title: "Titel: aus dem Frontmatter / mit Schrägstrich"
tags: [a, "b c"]
---
# Andere Überschrift im Text
Der Titel kommt aus dem Frontmatter.
