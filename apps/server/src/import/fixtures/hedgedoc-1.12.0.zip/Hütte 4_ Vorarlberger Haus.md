---
tags: hütte, vorarlberg
---
# Hütte 4: Vorarlberger Haus
Lage: Vorarlberg, 1348 m.

Vorher: [Hütte 3](http://127.0.0.1:8097/_rv8JjI7QKW4Zro_3gJeqQ)

- [ ] reservieren
- [ ] Beitrag bezahlt
