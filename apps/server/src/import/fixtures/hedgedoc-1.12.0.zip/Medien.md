# Medien
{%youtube 1G4isv_Fylg %}

{%vimeo 124148255 %}

{%gist hedgedoc/7ba9f8c7f8dfc4b4fb7a %}

Bilder: ![PNG](http://127.0.0.1:8097/uploads/75ccfb40-26fd-459d-aa51-8564d1dbeefc.png) ![GIF](http://127.0.0.1:8097/uploads/58ed8194-c6a6-4f05-b7c2-b440f32d55f5.gif =200x)

Externes Bild: ![extern](https://example.invalid/bild.png)
