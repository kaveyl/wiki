---
tags: hütte, tirol
---
# Hütte 16: Tiroler Haus
Lage: Tirol, 1792 m.

Vorher: [Hütte 15](http://127.0.0.1:8097/JrVJPirIQ-2OdtKdL-1iMQ)

- [ ] reservieren
- [ ] Beitrag bezahlt
