---
title: Hütte 29
updated: 2026-10-28 17:34:41Z
created: 2026-10-28 17:34:41Z
---

Lage: 2273 m.

Vorher: [Hütte 28](../Verein%20Alpenrose/Vorstand/Hütte%2028.md)
