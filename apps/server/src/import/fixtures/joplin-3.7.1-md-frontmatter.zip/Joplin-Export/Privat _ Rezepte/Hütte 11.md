---
title: Hütte 11
updated: 2026-10-28 17:34:40Z
created: 2026-10-28 17:34:40Z
---

Lage: 1607 m.

Vorher: [Hütte 10](../Verein%20Alpenrose/Vorstand/Hütte%2010.md)
