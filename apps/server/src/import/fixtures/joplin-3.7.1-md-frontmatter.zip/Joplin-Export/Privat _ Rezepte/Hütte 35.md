---
title: Hütte 35
updated: 2026-10-28 17:34:41Z
created: 2026-10-28 17:34:41Z
---

Lage: 2495 m.

Vorher: [Hütte 34](../Verein%20Alpenrose/Vorstand/Hütte%2034.md)
