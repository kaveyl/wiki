---
title: Hütte 5
updated: 2026-10-28 17:34:40Z
created: 2026-10-28 17:34:40Z
---

Lage: 1385 m.

Vorher: [Hütte 4](../Verein%20Alpenrose/Vorstand/Hütte%204.md)
