---
title: 'Rezept: Kaiserschmarrn'
updated: 2026-10-28 17:34:40Z
created: 2026-10-28 17:34:40Z
---

## Zutaten

- 4 Eier
- 250 ml Milch

## Zubereitung

Alles verrühren.
