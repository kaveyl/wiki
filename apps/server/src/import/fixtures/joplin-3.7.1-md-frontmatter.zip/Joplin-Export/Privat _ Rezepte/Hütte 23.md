---
title: Hütte 23
updated: 2026-10-28 17:34:40Z
created: 2026-10-28 17:34:40Z
---

Lage: 2051 m.

Vorher: [Hütte 22](../Verein%20Alpenrose/Vorstand/Hütte%2022.md)
