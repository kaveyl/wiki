---
title: Hütte 6
updated: 2026-10-28 17:34:40Z
created: 2026-10-28 17:34:40Z
tags:
  - Übernachtung mit Frühstück
---

Lage: 1422 m.

Vorher: [Hütte 5](../../Privat%20_%20Rezepte/Hütte%205.md)
