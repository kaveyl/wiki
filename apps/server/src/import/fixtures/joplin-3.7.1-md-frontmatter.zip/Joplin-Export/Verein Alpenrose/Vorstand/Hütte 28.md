---
title: Hütte 28
updated: 2026-10-28 17:34:41Z
created: 2026-10-28 17:34:41Z
---

Lage: 2236 m.

Vorher: [Hütte 27](../../Verein%20Alpenrose/Touren/Archiv/Hütte%2027.md)
