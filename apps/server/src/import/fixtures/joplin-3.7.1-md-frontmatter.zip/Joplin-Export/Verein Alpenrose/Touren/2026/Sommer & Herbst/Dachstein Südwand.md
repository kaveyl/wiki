---
title: Dachstein Südwand
updated: 2026-10-28 17:34:40Z
created: 2026-10-28 17:34:40Z
---

Schwierigkeit: **C**

![Gipfel](../../../../_resources/Foto%20vom%20Berg.jpg)

Siehe [Tourenplan](../../../../Verein%20Alpenrose/Touren/2026/Tourenplan%202026.md).
