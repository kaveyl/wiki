---
title: Protokoll
updated: 2026-10-28 17:34:40Z
created: 2026-10-28 17:34:40Z
---

Altes Protokoll von 2019.

Vergleiche [neues Protokoll](../../../Verein%20Alpenrose/Vorstand/Protokoll.md).
