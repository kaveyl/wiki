---
title: Hütte 18
updated: 2026-10-28 17:34:40Z
created: 2026-10-28 17:34:40Z
tags:
  - Übernachtung mit Frühstück
---

Lage: 1866 m.

Vorher: [Hütte 17](../../Privat%20_%20Rezepte/Hütte%2017.md)
