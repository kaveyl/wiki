---
title: Großglockner-Blick
updated: 2026-10-28 17:34:40Z
created: 2026-10-28 17:34:40Z
---

Treffpunkt 7 Uhr.

- [x] Hütte reserviert
- [ ] Bus bestellt
