---
title: Protokoll
updated: 2026-10-28 17:34:40Z
created: 2026-10-28 17:34:40Z
tags:
  - vorstand
---

Sitzung März.

Anwesend: 7.
