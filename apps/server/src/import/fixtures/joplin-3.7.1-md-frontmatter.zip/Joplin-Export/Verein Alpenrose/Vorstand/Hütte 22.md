---
title: Hütte 22
updated: 2026-10-28 17:34:40Z
created: 2026-10-28 17:34:40Z
---

Lage: 2014 m.

Vorher: [Hütte 21](../../Verein%20Alpenrose/Touren/Archiv/Hütte%2021.md)
