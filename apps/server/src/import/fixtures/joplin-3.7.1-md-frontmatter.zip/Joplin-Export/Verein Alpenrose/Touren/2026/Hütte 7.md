---
title: Hütte 7
updated: 2026-10-28 17:34:40Z
created: 2026-10-28 17:34:40Z
---

Lage: 1459 m.

Vorher: [Hütte 6](../../../Verein%20Alpenrose/Touren/Hütte%206.md)
