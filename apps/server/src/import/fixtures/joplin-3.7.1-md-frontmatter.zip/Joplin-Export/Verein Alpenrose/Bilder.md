---
title: Bilder
updated: 2026-10-28 17:34:40Z
created: 2026-10-28 17:34:40Z
---

![PNG](../_resources/bild-test.png) ![GIF](../_resources/animiert.gif)

Dasselbe Logo wie auf der Startseite: ![Logo](../_resources/logo.svg)

<img src="../_resources/bild-test.png" width="120">

Extern: ![extern](https://example.invalid/bild.png)

Kaputter Link: [weg](:/0123456789abcdef0123456789abcdef)
