---
title: Hütte 13
updated: 2026-10-28 17:34:40Z
created: 2026-10-28 17:34:40Z
---

Lage: 1681 m.

Vorher: [Hütte 12](../../../Verein%20Alpenrose/Touren/Hütte%2012.md)
