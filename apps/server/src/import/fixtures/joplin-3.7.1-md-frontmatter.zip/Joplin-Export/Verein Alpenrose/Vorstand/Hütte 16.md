---
title: Hütte 16
updated: 2026-10-28 17:34:40Z
created: 2026-10-28 17:34:40Z
---

Lage: 1792 m.

Vorher: [Hütte 15](../../Verein%20Alpenrose/Touren/Archiv/Hütte%2015.md)
