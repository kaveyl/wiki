---
title: 'Größe: 50 l? <Rucksack> "Test" | *'
updated: 2026-10-28 17:34:40Z
created: 2026-10-28 17:34:40Z
---

Sonderzeichen im Titel.
