---
title: Hütte 20
updated: 2026-10-28 17:34:40Z
created: 2026-10-28 17:34:40Z
---

Lage: 1940 m.

Vorher: [Hütte 19](../../../../Verein%20Alpenrose/Touren/2026/Hütte%2019.md)
