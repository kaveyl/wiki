---
title: Hütte 32
updated: 2026-10-28 17:34:41Z
created: 2026-10-28 17:34:41Z
---

Lage: 2384 m.

Vorher: [Hütte 31](../../../../Verein%20Alpenrose/Touren/2026/Hütte%2031.md)
