---
title: Hütte 25
updated: 2026-10-28 17:34:41Z
created: 2026-10-28 17:34:41Z
---

Lage: 2125 m.

Vorher: [Hütte 24](../../../Verein%20Alpenrose/Touren/Hütte%2024.md)
