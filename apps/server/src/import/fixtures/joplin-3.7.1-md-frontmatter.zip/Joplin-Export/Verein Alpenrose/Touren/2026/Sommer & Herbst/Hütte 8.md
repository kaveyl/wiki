---
title: Hütte 8
updated: 2026-10-28 17:34:40Z
created: 2026-10-28 17:34:40Z
---

Lage: 1496 m.

Vorher: [Hütte 7](../../../../Verein%20Alpenrose/Touren/2026/Hütte%207.md)
