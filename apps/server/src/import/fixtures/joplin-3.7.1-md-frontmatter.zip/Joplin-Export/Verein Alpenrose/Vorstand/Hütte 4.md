---
title: Hütte 4
updated: 2026-10-28 17:34:40Z
created: 2026-10-28 17:34:40Z
---

Lage: 1348 m.

Vorher: [Hütte 3](../../Verein%20Alpenrose/Touren/Archiv/Hütte%203.md)
