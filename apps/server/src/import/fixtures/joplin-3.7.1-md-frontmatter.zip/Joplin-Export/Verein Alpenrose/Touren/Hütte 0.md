---
title: Hütte 0
updated: 2026-10-28 17:34:40Z
created: 2026-10-28 17:34:40Z
tags:
  - Übernachtung mit Frühstück
---

Lage: 1200 m.

