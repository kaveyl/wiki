---
title: Hütte 12
updated: 2026-10-28 17:34:40Z
created: 2026-10-28 17:34:40Z
tags:
  - Übernachtung mit Frühstück
---

Lage: 1644 m.

Vorher: [Hütte 11](../../Privat%20_%20Rezepte/Hütte%2011.md)
