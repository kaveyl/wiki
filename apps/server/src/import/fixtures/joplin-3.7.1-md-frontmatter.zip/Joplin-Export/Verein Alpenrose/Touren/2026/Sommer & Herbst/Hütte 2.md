---
title: Hütte 2
updated: 2026-10-28 17:34:40Z
created: 2026-10-28 17:34:40Z
---

Lage: 1274 m.

Vorher: [Hütte 1](../../../../Verein%20Alpenrose/Touren/2026/Hütte%201.md)
