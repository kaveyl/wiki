---
title: Hütte 1
updated: 2026-10-28 17:34:40Z
created: 2026-10-28 17:34:40Z
---

Lage: 1237 m.

Vorher: [Hütte 0](../../../Verein%20Alpenrose/Touren/Hütte%200.md)
