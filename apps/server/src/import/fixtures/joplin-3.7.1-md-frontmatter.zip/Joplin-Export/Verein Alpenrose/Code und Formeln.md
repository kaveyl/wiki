---
title: Code und Formeln
updated: 2026-10-28 17:34:40Z
created: 2026-10-28 17:34:40Z
---

```js
const hm = (a, b) => Math.abs(b - a);
```

Inline $E = mc^2$ und

$$
\sum_i h_i = H
$$

```mermaid
graph TD
  A[Parkplatz] --> B(Hütte)
```

==markiert== und ~~gestrichen~~, Fußnote[^1].

[^1]: Fußnotentext.
