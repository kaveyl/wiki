---
title: Hütte 15
updated: 2026-10-28 17:34:40Z
created: 2026-10-28 17:34:40Z
tags:
  - hütte
---

Lage: 1755 m.

Vorher: [Hütte 14](../../../Verein%20Alpenrose/Touren/2026/Sommer%20&%20Herbst/Hütte%2014.md)
