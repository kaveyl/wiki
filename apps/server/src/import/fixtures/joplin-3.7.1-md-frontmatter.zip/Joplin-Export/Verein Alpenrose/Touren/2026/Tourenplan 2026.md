---
title: Tourenplan 2026
updated: 2026-10-28 17:34:40Z
created: 2026-10-28 17:34:40Z
source: https://example.invalid/touren
author: Anna-Lena
latitude: 47.07420000
longitude: 12.69470000
altitude: 2571.0000
tags:
  - 2026
  - touren
---

| Datum | Ziel | Höhe |
|---|---|---:|
| 12.06. | Großglockner-Blick | 2.571 m |
| 03.07. | Dachstein | 2.995 m |

![Gipfel](../../../_resources/Foto%20vom%20Berg.jpg)

Der Plan als PDF: [Tourenplan 2026.pdf](../../../_resources/Tourenplan%202026.pdf)

Zurück zur [Startseite](../../../Verein%20Alpenrose/Willkommen.md) oder zum [Beitritt](../../../Verein%20Alpenrose/Willkommen.md#beitritt).
