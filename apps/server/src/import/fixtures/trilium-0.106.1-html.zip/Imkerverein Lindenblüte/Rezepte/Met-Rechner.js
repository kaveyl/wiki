// Met-Rechner: Honigmenge für gewünschten Alkoholgehalt
function honigFuer(liter, prozent) {
  return Math.round(liter * prozent * 17.5);
}
console.log(`20 l mit 12 %: ${honigFuer(20, 12)} g Honig`);
