# Rezeptideen

- **Honigsenf**: Senfkörner, Honig, Essig
- [Honigkuchen](Honigkuchen.html)

> [!TIP]
> Waldhonig kristallisiert langsamer.
