region:: Tirol
tags:: hütte

- Lage: 2236 m. #übernachtung
- Vorher: [[Hütten/Salzburg/Hütte 27]]