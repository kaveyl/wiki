region:: Salzburg
tags:: hütte

- Lage: 1385 m. #übernachtung
- Vorher: [[Hütten/Hütte 4]]