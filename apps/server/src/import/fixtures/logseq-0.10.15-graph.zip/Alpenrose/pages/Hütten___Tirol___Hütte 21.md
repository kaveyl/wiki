region:: Salzburg
tags:: hütte

- Lage: 1977 m. #übernachtung
- Vorher: [[Hütten/Hütte 20]]