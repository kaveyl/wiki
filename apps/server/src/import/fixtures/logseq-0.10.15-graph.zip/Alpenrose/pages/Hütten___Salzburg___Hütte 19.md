region:: Steiermark
tags:: hütte

- Lage: 1903 m. #übernachtung
- Vorher: [[Hütten/Tirol/Ost/Hütte 18]]