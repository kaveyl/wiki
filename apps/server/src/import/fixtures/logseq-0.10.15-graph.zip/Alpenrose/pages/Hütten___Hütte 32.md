region:: Tirol
tags:: hütte

- Lage: 2384 m. #übernachtung
- Vorher: [[Hütten/Salzburg/Hütte 31]]