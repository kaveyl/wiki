region:: Tirol
tags:: hütte

- Lage: 1644 m. #übernachtung
- Vorher: [[Hütten/Salzburg/Hütte 11]]