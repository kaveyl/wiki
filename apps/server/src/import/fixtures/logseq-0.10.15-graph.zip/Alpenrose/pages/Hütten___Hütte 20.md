region:: Tirol
tags:: hütte

- Lage: 1940 m. #übernachtung
- Vorher: [[Hütten/Salzburg/Hütte 19]]