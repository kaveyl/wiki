- TODO Bus bestellen
  SCHEDULED: <2026-11-02 Mon>
- DOING Hütte reservieren
- DONE Tourenplan verschicken
- LATER [#A] Wetter prüfen
  DEADLINE: <2026-11-05 Thu>
- NOW Rucksack packen
- WAITING Antwort vom Hüttenwirt
- CANCELED Bergfest
- {{query (task TODO LATER)}}
- #+BEGIN_QUERY
  {:title "Offene Aufgaben"
   :query [:find (pull ?b [*]) :where [?b :block/marker ?m] [(contains? #{"TODO" "LATER"} ?m)]]}
  #+END_QUERY