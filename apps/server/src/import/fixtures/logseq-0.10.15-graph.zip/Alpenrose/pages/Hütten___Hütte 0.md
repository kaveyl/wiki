region:: Tirol
tags:: hütte

- Lage: 1200 m. #übernachtung