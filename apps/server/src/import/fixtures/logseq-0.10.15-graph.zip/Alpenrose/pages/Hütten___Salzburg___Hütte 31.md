region:: Steiermark
tags:: hütte

- Lage: 2347 m. #übernachtung
- Vorher: [[Hütten/Tirol/Ost/Hütte 30]]