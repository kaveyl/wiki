region:: Tirol
tags:: hütte

- Lage: 1792 m. #übernachtung
- Vorher: [[Hütten/Salzburg/Hütte 15]]