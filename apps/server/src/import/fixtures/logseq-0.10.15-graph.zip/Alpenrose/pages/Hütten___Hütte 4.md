region:: Tirol
tags:: hütte

- Lage: 1348 m. #übernachtung
- Vorher: [[Hütten/Salzburg/Hütte 3]]