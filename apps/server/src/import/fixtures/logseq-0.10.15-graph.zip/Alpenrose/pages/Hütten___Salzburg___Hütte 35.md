region:: Steiermark
tags:: hütte

- Lage: 2495 m. #übernachtung
- Vorher: [[Hütten/Tirol/Ost/Hütte 34]]