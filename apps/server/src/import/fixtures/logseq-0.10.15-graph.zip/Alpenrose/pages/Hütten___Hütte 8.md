region:: Tirol
tags:: hütte

- Lage: 1496 m. #übernachtung
- Vorher: [[Hütten/Salzburg/Hütte 7]]