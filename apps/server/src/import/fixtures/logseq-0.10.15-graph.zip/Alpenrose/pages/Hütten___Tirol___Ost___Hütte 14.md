region:: Kärnten
tags:: hütte

- Lage: 1718 m. #übernachtung
- Vorher: [[Hütten/Tirol/Hütte 13]]