region:: Steiermark
tags:: hütte

- Lage: 1755 m. #übernachtung
- Vorher: [[Hütten/Tirol/Ost/Hütte 14]]