region:: Salzburg
tags:: hütte

- Lage: 1237 m. #übernachtung
- Vorher: [[Hütten/Hütte 0]]