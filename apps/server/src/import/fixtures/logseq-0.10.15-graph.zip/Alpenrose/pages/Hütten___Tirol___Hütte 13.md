region:: Salzburg
tags:: hütte

- Lage: 1681 m. #übernachtung
- Vorher: [[Hütten/Hütte 12]]