region:: Steiermark
tags:: hütte

- Lage: 1607 m. #übernachtung
- Vorher: [[Hütten/Tirol/Ost/Hütte 10]]