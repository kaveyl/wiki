region:: Kärnten
tags:: hütte

- Lage: 1274 m. #übernachtung
- Vorher: [[Hütten/Tirol/Hütte 1]]