region:: Salzburg
tags:: hütte

- Lage: 1533 m. #übernachtung
- Vorher: [[Hütten/Hütte 8]]