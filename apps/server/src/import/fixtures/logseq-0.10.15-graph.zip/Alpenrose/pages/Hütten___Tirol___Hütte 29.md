region:: Salzburg
tags:: hütte

- Lage: 2273 m. #übernachtung
- Vorher: [[Hütten/Hütte 28]]