region:: Steiermark
tags:: hütte

- Lage: 2051 m. #übernachtung
- Vorher: [[Hütten/Tirol/Ost/Hütte 22]]