region:: Kärnten
tags:: hütte

- Lage: 1570 m. #übernachtung
- Vorher: [[Hütten/Tirol/Hütte 9]]