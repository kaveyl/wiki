- | Datum | Ziel | Höhe |
  |---|---|---:|
  | 12.06. | Großglockner-Blick | 2.571 m |
  | 03.07. | Dachstein | 2.995 m |
- ![Gipfel](../assets/foto-berg_1761690000100_0.jpg)
- Der Plan als PDF: ![tourenplan.pdf](../assets/tourenplan_1761690000400_0.pdf)
- Dachstein
  ort:: Ramsau
  höhe:: 2995
  schwierigkeit:: mittel