region:: Kärnten
tags:: hütte

- Lage: 2162 m. #übernachtung
- Vorher: [[Hütten/Tirol/Hütte 25]]