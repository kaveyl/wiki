region:: Steiermark
tags:: hütte

- Lage: 2199 m. #übernachtung
- Vorher: [[Hütten/Tirol/Ost/Hütte 26]]