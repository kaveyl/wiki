- Treffpunkt 7 Uhr am Parkplatz
  collapsed:: true
	- Eingeklappter Unterpunkt
- Animiert: ![GIF](../assets/animiert_1761690000200_0.gif) und ![PNG](../assets/bild-test_1761690000000_0.png)