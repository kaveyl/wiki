region:: Salzburg
tags:: hütte

- Lage: 1829 m. #übernachtung
- Vorher: [[Hütten/Hütte 16]]