region:: Kärnten
tags:: hütte

- Lage: 2458 m. #übernachtung
- Vorher: [[Hütten/Tirol/Hütte 33]]