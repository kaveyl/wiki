- ```js
  const hm = (a, b) => Math.abs(b - a); // [[kein Link]]
  ```
- $$E = mc^2$$
- Inline $h_i$ und `[[auch kein Link]]`
- > Ein Zitat
  > über zwei Zeilen
- #+BEGIN_NOTE
  Ein Hinweis im Logseq-Stil
  #+END_NOTE
- #+BEGIN_WARNING
  Steinschlaggefahr!
  #+END_WARNING