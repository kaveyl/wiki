region:: Kärnten
tags:: hütte

- Lage: 1866 m. #übernachtung
- Vorher: [[Hütten/Tirol/Hütte 17]]