region:: Salzburg
tags:: hütte

- Lage: 2421 m. #übernachtung
- Vorher: [[Hütten/Hütte 32]]