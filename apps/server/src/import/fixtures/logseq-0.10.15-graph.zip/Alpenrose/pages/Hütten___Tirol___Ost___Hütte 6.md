region:: Kärnten
tags:: hütte

- Lage: 1422 m. #übernachtung
- Vorher: [[Hütten/Tirol/Hütte 5]]