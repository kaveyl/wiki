- Anwesend: 7
- Beschluss: Mitgliedsbeitrag 30 € ab 2027
  id:: 6ae254af-fe15-45f2-afd1-6e9435955985