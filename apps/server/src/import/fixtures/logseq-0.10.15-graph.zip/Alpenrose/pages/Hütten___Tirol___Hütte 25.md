region:: Salzburg
tags:: hütte

- Lage: 2125 m. #übernachtung
- Vorher: [[Hütten/Hütte 24]]