region:: Steiermark
tags:: hütte

- Lage: 1311 m. #übernachtung
- Vorher: [[Hütten/Tirol/Ost/Hütte 2]]