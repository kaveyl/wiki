region:: Tirol
tags:: hütte

- Lage: 2088 m. #übernachtung
- Vorher: [[Hütten/Salzburg/Hütte 23]]