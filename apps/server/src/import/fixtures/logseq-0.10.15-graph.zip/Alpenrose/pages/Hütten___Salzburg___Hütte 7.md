region:: Steiermark
tags:: hütte

- Lage: 1459 m. #übernachtung
- Vorher: [[Hütten/Tirol/Ost/Hütte 6]]