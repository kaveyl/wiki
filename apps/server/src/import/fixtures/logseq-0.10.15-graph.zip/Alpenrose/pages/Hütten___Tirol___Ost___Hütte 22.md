region:: Kärnten
tags:: hütte

- Lage: 2014 m. #übernachtung
- Vorher: [[Hütten/Tirol/Hütte 21]]