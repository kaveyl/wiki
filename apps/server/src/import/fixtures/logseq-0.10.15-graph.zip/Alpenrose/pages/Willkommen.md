alias:: Start, Startseite
tags:: verein, [[Wichtige Seiten]]

- Wir wandern seit 1987. ![Logo](../assets/logo_1761690000300_0.svg)
- Zu den [[Touren/2026]] und zum [[Vorstand/Protokoll März]]. Siehe auch [[Gibt es nicht]] und [die Hütten]([[Hütten]]).
	- Unterpunkt mit **fett**, *kursiv*, ==markiert==, ^^hervorgehoben^^ und ~~gestrichen~~
	- Zweite Ebene
		- Dritte Ebene mit #wichtig und #[[zwei Wörter]]
- ## Kontakt
  heading:: 2
- Mail an [vorstand@alpenrose.invalid](mailto:vorstand@alpenrose.invalid) oder https://example.invalid/alpenrose
- Siehe den Beschluss ((6ae254af-fe15-45f2-afd1-6e9435955985))
- {{embed ((6ae254af-fe15-45f2-afd1-6e9435955985))}}
- {{embed [[Touren/2026]]}}