# Imkerverein Lindenblüte
Willkommen im Wiki des **Imkervereins Lindenblüte** (gegründet 1987, erfunden). Hier sammeln wir Protokolle, Völkerkarten, Rezepte und alles rund um die Bienen.