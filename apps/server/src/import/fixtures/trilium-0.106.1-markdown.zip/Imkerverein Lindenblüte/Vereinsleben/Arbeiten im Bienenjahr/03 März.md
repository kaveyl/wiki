# 03 März
Reinigungsflug beobachten.