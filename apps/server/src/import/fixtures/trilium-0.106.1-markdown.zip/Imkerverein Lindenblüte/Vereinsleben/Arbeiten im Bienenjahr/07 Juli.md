# 07 Juli
Sommertracht ernten.