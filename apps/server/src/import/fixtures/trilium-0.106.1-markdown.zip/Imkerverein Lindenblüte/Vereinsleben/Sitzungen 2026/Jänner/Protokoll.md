# Protokoll
## Tagesordnung

1.  Begrüßung
2.  Winterbehandlung
3.  Allfälliges

Beschluss: Oxalsäure-Träufelbehandlung bis 15. Jänner abschließen.