# 01 Jänner
Ruhe, Totenfall prüfen.