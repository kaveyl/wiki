# Protokoll
## Tagesordnung

1.  Kassabericht
2.  Bestellung Mittelwände

Siehe auch das [Protokoll vom Jänner](../J%C3%A4nner/Protokoll.md).