# Protokoll
Jahreshauptversammlung – Protokoll B (gleicher Titel).