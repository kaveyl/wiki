# Vorstand
## Zusammensetzung

*   Obfrau: Hilde Wabenreich
*   Kassier: Bruno Honigmann
*   Schriftführung: Greta Pollinger

Sprechstunde jeden ersten Montag im Vereinsheim.