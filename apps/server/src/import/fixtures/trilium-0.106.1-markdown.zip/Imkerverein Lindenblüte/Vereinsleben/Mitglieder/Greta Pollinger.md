# Greta Pollinger
Mitglied seit 2015. Stand: aktiv.