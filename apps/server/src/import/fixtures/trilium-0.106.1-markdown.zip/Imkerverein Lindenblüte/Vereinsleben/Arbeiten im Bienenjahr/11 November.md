# 11 November
Winterruhe.