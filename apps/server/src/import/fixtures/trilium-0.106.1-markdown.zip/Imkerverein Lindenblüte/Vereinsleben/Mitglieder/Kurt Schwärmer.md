# Kurt Schwärmer
Mitglied seit 2014. Stand: ruhend.