# Ömer Blütenstaub
Mitglied seit 2016. Stand: Jungimker.