# Protokoll
Jahreshauptversammlung – Protokoll A.