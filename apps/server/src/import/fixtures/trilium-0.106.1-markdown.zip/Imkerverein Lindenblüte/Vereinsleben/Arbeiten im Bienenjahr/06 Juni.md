# 06 Juni
Frühtracht ernten.