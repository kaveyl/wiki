# 02 Februar
Futterkontrolle.