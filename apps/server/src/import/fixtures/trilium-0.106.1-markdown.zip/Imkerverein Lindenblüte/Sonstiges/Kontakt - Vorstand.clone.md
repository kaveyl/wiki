# Vorstand
This is a clone of a note. Go to its [primary location](../Vereinsleben/Vorstand.md).