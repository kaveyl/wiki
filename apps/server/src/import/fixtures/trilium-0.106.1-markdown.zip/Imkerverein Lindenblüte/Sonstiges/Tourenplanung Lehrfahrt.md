# Tourenplanung Lehrfahrt
Lehrfahrt zur Belegstelle am 12. Juni. Plan als Anhang: <a class="reference-link" href="Tourenplanung Lehrfahrt_tourenplan.pdf">tourenplan.pdf</a>.

Download-Link: [tourenplan.pdf herunterladen](api/attachments/opDqojJCZTnS/download)

Datei-Notiz: <a class="reference-link" href="../Medien/Tourenplan%20Lehrfahrt.pdf">Tourenplan Lehrfahrt</a>