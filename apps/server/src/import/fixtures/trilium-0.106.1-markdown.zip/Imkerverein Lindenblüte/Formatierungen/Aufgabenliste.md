# Aufgabenliste
- [x] Rähmchen drahten
- [ ] Mittelwände einlöten
- [x] Gläser bestellen
    - [x] 500 g