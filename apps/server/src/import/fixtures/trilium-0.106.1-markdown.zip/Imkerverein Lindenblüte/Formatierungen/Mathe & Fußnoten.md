# Mathe & Fußnoten
Inline: $A = \pi r^2$ ist die Fläche.

$$\sum_{i=1}^{n} w_i = 40\,000$$

Eine Biene fliegt bis zu 3 km weit<sup><a href="#fnfa1b2c3d4e5f">[1]</a></sup>.

1.  <sup><strong><a href="#fnreffa1b2c3d4e5f">^</a></strong></sup>
    
    Laut Vereinsheft 3/2026 (erfunden).