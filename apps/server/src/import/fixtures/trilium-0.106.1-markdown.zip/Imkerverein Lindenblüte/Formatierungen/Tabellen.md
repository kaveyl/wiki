# Tabellen
| Volk | Ertrag (kg) | Note |
| --- | --- | --- |
| Gelb | 18,5 | **sehr gut** |
| Weiß | 11 | gut \| stabil |

<table>
    <tbody>
        <tr>
            <td colspan="2">verbunden</td>
        </tr>
        <tr>
            <td>a</td>
            <td><p>Absatz 1</p><p>Absatz 2</p></td>
        </tr>
    </tbody>
</table>