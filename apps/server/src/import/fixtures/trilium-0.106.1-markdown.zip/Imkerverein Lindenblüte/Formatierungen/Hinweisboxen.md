# Hinweisboxen
> [!NOTE]
> Hinweis: Schleier tragen.

> [!TIP]
> Tipp: Rauch sparsam einsetzen.

> [!IMPORTANT]
> Wichtig: Stockkarte führen.

> [!CAUTION]
> Vorsicht: Ameisensäure ätzt.

> [!WARNING]
> Warnung: Allergiker-Notfallset bereithalten.
> 
> *   mit Liste