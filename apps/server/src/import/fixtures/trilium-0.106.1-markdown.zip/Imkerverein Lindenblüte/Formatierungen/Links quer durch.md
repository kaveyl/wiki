# Links quer durch
Verweis (reference-link): <a class="reference-link" href="../Vereinsleben/Vorstand.md">Vorstand</a>

Normaler interner Link: [unser bestes Volk](../Bienenhaltung/V%C3%B6lker%20%26%20St%C3%A4nde/Stand%20%E2%80%9EAm%20Lindenhang%E2%80%9C/Volk%201%20K%C3%B6nigin%20Gelb.md)

Link auf eine Überschrift: [Zusammensetzung des Vorstands](../Vereinsleben/Vorstand.md)

Link auf ein gleichnamiges Protokoll: [Protokoll Februar](../Vereinsleben/Sitzungen%202026/Februar/Protokoll.md) und [Protokoll B](../Vereinsleben/Sitzungen%202026/1_Protokoll.md)

Link mit Sonderzeichen-Ziel: [Varroa 60 %](../Bienenhaltung/Varroa-Behandlung%20Ameisens%C3%A4ure%2060%20%25.md), [Futter 3:2](../Bienenhaltung/FutterZucker-Mischung%2032.md), [Schwarm #3](../Bienenhaltung/Schwarmkontrolle%20%233.md), [Ernte?](../Bienenhaltung/Honigernte%20%E2%80%93%20was%20tun.md), [Völker & Stände](../Bienenhaltung/V%C3%B6lker%20%26%20St%C3%A4nde)

Link auf Ordner ohne Text: [Bienenhaltung](../Bienenhaltung); auf Notiz mit Text+Kindern: [Sitzungen 2026](../Vereinsleben/Sitzungen%202026.md)

Link auf Code-Notiz: <a class="reference-link" href="../Rezepte/Met-Rechner.js">Met-Rechner</a>, auf Bild-Notiz: <a class="reference-link" href="../Medien/Testbild.png">Testbild</a>, auf Mermaid: <a class="reference-link" href="../Diagramme/Ablauf%20Honigernte.txt">Ablauf Honigernte</a>, auf Canvas: <a class="reference-link" href="../Diagramme/Bienenstand-Skizze.json">Bienenstand-Skizze</a>

Link auf geschützte Notiz: <a class="reference-link" href="../Sonstiges/%5Bprotected%5D">Kassabuch (geschützt)</a>

Link ins Leere (Notiz gibt es nicht): [Verschollene Notiz](#root/abcdefghijkl)

Extern: [example.org/bienen](https://example.org/bienen) und [Mail an die Obfrau](mailto:obfrau@example.org)