# Text und Überschriften
## Überschrift 2

### Überschrift 3

#### Überschrift 4

**fett**, _kursiv_, unterstrichen, ~~durchgestrichen~~, `inline-code`, <sub>tief</sub>, <sup>hoch</sup>, <kbd>Strg</kbd>+<kbd>S</kbd>.

<mark class="marker-yellow">gelb markiert</mark>, ==Hintergrund gelb==, <span style="color:hsl(0,75%,60%);">rote Schrift</span>.

> Die Biene ist das einzige Tier, das dem Menschen Nahrung gibt, ohne ihm etwas zu nehmen. (erfunden)

---

1.  eins
    1.  eins-a
2.  zwei

*   Punkt
    *   Unterpunkt

zentriert

<details>
    <summary>Aufklappen</summary>
    <p>Versteckter Text.</p>
</details>