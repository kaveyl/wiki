# Eingebettete Notiz
Hier wird das Protokoll vom Jänner eingebettet:

<section class="include-note" data-note-id="SqhYSnFiIY0o" data-box-size="medium">&nbsp;</section>

Und das Mermaid-Diagramm:

<section class="include-note" data-note-id="DTWQdH1sKuLF" data-box-size="full">&nbsp;</section>