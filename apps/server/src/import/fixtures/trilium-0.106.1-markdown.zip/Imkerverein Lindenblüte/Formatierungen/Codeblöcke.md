# Codeblöcke
```python
print("Summ summ")
```

```javascript
const bienen = 40000;
```

```sh
echo "Honig" | wc -c
```

```plain
Nur Text ohne Sprache
```

```
automatisch erkannt
```

```mermaid
graph TD; A-->B;
```