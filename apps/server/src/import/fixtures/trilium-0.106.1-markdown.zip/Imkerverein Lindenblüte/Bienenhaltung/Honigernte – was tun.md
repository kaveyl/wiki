# Honigernte – was tun?
Wassergehalt unter 18 % messen, dann schleudern.