# Volk 1: Königin Gelb
This is a clone of a note. Go to its [primary location](V%C3%B6lker%20%26%20St%C3%A4nde/Stand%20%E2%80%9EAm%20Lindenhang%E2%80%9C/Volk%201%20K%C3%B6nigin%20Gelb.md).