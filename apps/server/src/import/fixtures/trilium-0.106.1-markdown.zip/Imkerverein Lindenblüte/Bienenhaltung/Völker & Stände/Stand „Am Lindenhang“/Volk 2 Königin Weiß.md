# Volk 2: Königin Weiß
Königin 2026, weiß gezeichnet, etwas stechlustig.