# Stand „Am Lindenhang“
Sechs Völker auf 420 m, Südosthang, Tracht: Linde, Robinie, Waldhonig.