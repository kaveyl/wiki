# Volk 1: Königin Gelb
Königin 2025, gelb gezeichnet, sanftmütig.