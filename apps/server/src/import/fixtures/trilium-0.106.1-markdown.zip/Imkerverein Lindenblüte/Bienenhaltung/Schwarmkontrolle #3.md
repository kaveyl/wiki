# Schwarmkontrolle #3
Dritte Kontrolle: Weiselzellen brechen.