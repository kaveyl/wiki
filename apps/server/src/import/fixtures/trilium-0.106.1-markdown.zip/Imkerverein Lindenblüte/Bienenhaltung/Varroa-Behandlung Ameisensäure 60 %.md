# Varroa-Behandlung: Ameisensäure 60 %
Langzeitverdunster, 60 % Ameisensäure, nur unter 25 °C.