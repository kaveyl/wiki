# Futter/Zucker-Mischung 3:2
3 Teile Zucker auf 2 Teile Wasser.