# Honigkuchen
Zutaten: 250 g Honig, 2 Eier, 300 g Mehl, Lebkuchengewürz.

<figure class="image"><img src="Honigkuchen_bild-test.png" alt="Teig in der Form"></figure><figure class="image image-style-align-right" style="width:25%;"><img style="aspect-ratio:320/200;" src="Honigkuchen_bild-test.png" width="320" height="200"></figure>

Foto vom Stand (Bildnotiz eingebettet):

<figure class="image"><img src="../Medien/Bienenstand-Foto.jpg"></figure>

Inline-Bild: ![Logo](../Medien/Vereinslogo.svg) im Satz.