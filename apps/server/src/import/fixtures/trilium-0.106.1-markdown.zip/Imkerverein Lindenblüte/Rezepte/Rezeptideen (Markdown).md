# Rezeptideen

- **Honigsenf**: Senfkörner, Honig, Essig
- [Honigkuchen](Honigkuchen.md)

> [!TIP]
> Waldhonig kristallisiert langsamer.
