# Alter Entwurf

Wird gelöscht und landet im Papierkorb von Obsidian.
