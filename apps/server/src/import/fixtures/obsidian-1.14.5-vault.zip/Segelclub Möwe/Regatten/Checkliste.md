# Checkliste Regatta

- [ ] Meldung abgeschickt
- [ ] Segelnummer am Segel
- [ ] Startzeit notiert

Gleichnamig: [[Boote/Wartung/Checkliste]] und [[Ausbildung/Checkliste]].
