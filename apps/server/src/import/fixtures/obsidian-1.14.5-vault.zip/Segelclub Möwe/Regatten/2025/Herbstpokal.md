# Herbstpokal 2025

Ausgefallen wegen Sturm. Nächstes Jahr: [[Regatten/2026/Herbstpokal]].
