# Fotos vom Steg

![200](../../../../Anhänge/Fotos/Steg%20im%20Herbst.jpg)

Eingebettete Notiz: ![420er](../../../../Boote/Jollen/420er.md)
