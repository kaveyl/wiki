---
regatta: "[[Regatten/2026/Frühjahrsregatta|Frühjahrsregatta]]"
sieger: "[[../../../../Boote/Kielboote/Möwe II]]"
punkte:
  - 4
  - 7
  - 9
---
# Wertung Sommer 2026

| Platz | Boot | Punkte |
|--:|---|--:|
| 1 | [Möwe II](../../../../Boote/Kielboote/Möwe%20II.md) | 4 |
| 2 | [420er](../../../../Boote/Jollen/420er.md) | 7 |
| 3 | [Laser](../../../../Boote/Jollen/Laser.md) | 9 |

Regatta: [Frühjahrsregatta](../../../2026/Frühjahrsregatta.md#Ergebnis). Sommerfest danach: [Sommerfest 2026](../../../../Feste/Sommerfest%202026.md).
Ein Block: [Satzung](../../../../Verein/Satzung.md#^zweck). Plan: ![](../../../../Anhänge/tourenplan.pdf#page=1).
