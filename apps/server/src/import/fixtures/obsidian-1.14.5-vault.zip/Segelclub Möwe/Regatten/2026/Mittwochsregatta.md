# Mittwochsregatta

Jeden Mittwoch ab 18 Uhr. #boot

Von Hand getippt: [[Checkliste]] und [[Herbstpokal]].
