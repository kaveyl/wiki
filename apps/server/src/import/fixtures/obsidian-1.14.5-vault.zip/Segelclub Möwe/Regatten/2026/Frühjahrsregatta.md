---
datum: 2026-04-25
tags: regatta
fest: "[[../../Feste/Sommerfest 2026]]"
status: "offen: Meldung läuft"
publish: false
---
# Frühjahrsregatta 2026

## Meldeschluss

Der 15. April 2026, 18 Uhr. #regatta

## Bahn

Dreieckskurs, siehe Plan: ![[tourenplan.pdf]]

Nur Seite 1: ![[tourenplan.pdf#page=1]]

## Ergebnis

[[Wertung]] (vorläufig).
