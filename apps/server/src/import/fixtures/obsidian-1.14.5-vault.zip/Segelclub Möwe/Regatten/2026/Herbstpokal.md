# Herbstpokal 2026

Austragung am 10. Oktober. Vorjahr: [[Regatten/2025/Herbstpokal]].

> [!success] Ergebnis
> Sieg für die [[../../Boote/Kielboote/Möwe II]]!
