# {{title}}

| Länge | Breite | Segelfläche |
|---|---|---|
|  |  |  |
