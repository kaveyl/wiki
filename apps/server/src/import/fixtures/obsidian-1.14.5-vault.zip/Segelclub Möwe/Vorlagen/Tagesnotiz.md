---
tags:
  - tagebuch
---
# {{date:dddd, D. MMMM YYYY}}

Erstellt um {{time}} – {{title}}

## Wetter

## Notizen
