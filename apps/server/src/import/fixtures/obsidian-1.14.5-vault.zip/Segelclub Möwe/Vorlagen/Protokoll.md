# Vorstandssitzung {{date:MMMM YYYY}}

Anwesend:

## Tagesordnung

- [ ]

## Beschlüsse
