# Ansegeln

Erster Samstag im Mai. Boote müssen vorher gewassert sein: [Kran & Termine](../Boote/Wartung/Winterlager/Kran%20&%20Termine.md#Kran%20&%20Termine).
