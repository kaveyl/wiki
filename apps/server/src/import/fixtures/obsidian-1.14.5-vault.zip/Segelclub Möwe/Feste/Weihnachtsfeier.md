# Weihnachtsfeier

Im Clubhaus, siehe [Küche und Bar](../Hafen/Clubhaus/Küche%20und%20Bar.md). Wie im Sommer: [Sommerfest 2026](Sommerfest%202026.md).
