# Sommerfest

Am 18. Juli am Steg. Grillen, Musik, Kinderregatta mit [[Optimist|Optis]].

- Programm: [[Grillabend #3]]
- Aufbau ab 14 Uhr
