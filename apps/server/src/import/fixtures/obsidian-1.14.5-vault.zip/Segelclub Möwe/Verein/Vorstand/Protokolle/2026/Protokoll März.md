---
datum: 2026-03-12
beginn: 2026-03-12T19:30
teilnehmer: 3
beschlussfähig: true
ort: "[[../../../../Hafen/Clubhaus/Küche und Bar]]"
siehe:
  - "[[Verein/Vorstand/Protokolle/2026/Protokoll Juni|Protokoll Juni]]"
  - "[[Satzung#§ 3 Mitgliedschaft]]"
tags:
  - protokoll
  - vorstand/2026
kommentar:
---
# Vorstandssitzung März 2026

Anwesend: Kapitänin Wilma Wellenreiter, Kassenwart Odo Ankerplatz, Jugendwartin Fenja Kielwasser

## Tagesordnung

- [x] Protokoll Februar genehmigt
- [ ] Steg-Reparatur beauftragen
- [/] Angebote Kran einholen (zwei von drei da)
- [-] Neues Clubboot (vertagt)
- [>] Termin Sommerfest verschoben
- [?] Frage an die Gemeinde offen

## Beschlüsse

Der Beitrag steigt 2027 um 10 €. ^beschluss-beitrag

Die Jugendgruppe bekommt zwei neue Optimisten. ^b7f3a1

Nächstes Treffen: siehe [[Protokoll Juni]].

Eingefügtes Bild: ![[Pasted image 20261028222601.jpg]]
