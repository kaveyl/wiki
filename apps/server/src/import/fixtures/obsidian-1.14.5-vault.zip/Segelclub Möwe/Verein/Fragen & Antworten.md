# Fragen & Antworten

> [!faq]- Brauche ich einen Segelschein?
> Für Jollen auf dem Mühlsee nicht, für die Kielboote schon. Siehe [[../Ausbildung/Segelschein/Theorie & Regeln/Vorfahrtsregeln]].

> [!faq]+ Was kostet die Mitgliedschaft?
> Siehe [[Mitglieder & Beiträge#Beitragsordnung|Beitragsordnung]].

> [!question] Darf ich Gäste mitnehmen?
> Ja, zwei pro Ausfahrt.

> [!warning] Achtung bei Gewitter
> Sofort an Land! Mehr in [[../Ausbildung/Segelschein/Theorie & Regeln/Wetterkunde#Gewitter]].

> [!bug] Bekannter Fehler
> Die Buchungsliste zeigt manchmal doppelte Einträge.

> [!segelwetter] Eigener Typ ohne Bedeutung
> Callout-Typen, die Obsidian nicht kennt, sehen aus wie „note“.

> [!info] Verschachtelt
> Außen.
> > [!danger] Innen
> > Innen drin, mit **fett** und `Code`.
> > > [!success] Ganz innen
> > > Drei Ebenen.

> [!abstract]
> Callout ohne Titel und ohne Inhalt außer dieser Zeile.

>[!todo] Ohne Leerzeichen nach >
> Geht auch.
