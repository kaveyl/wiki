# Vorstandssitzung Juni 2026

Rückblick auf den Beschluss vom März: [[Verein/Vorstand/Protokolle/2026/Protokoll März#^beschluss-beitrag|Beitragserhöhung]]

Als Einbettung:

![[Verein/Vorstand/Protokolle/2026/Protokoll März#^beschluss-beitrag]]

Und die Optimisten: [[Verein/Vorstand/Protokolle/2026/Protokoll März#^b7f3a1]] – geliefert sind sie: [[Optimist]].

Ganzes Protokoll März eingebettet:

![[Verein/Vorstand/Protokolle/2026/Protokoll März]]

Der alte Plan 2025: [[Verein/Vorstand/Protokolle/2025/Protokoll März#Beschlüsse]].
