# Satzung des Segelclub Möwe e. V.

## § 1 Name und Sitz

Der Verein führt den Namen „Segelclub Möwe“ und hat seinen Sitz in Seedorf am Mühlsee.

## § 2 Zweck

Zweck des Vereins ist die Förderung des Segelsports, besonders der Jugendarbeit.[^1] ^zweck

Der Verein ist selbstlos tätig.[^gemein]

## § 3 Mitgliedschaft

Mitglied kann jede natürliche Person werden. Über die Aufnahme entscheidet der Vorstand. ^aufnahme

### Beiträge

Die Höhe regelt die Beitragsordnung, siehe [[Mitglieder & Beiträge#Beitragsordnung]].

## § 4 Organe

1. Mitgliederversammlung
2. Vorstand
3. Jugendausschuss

## § 5 Auflösung

Bei Auflösung fällt das Vermögen an die Gemeinde Seedorf.

[^1]: Gemäß Abgabenordnung, Abschnitt „Steuerbegünstigte Zwecke“.
[^gemein]: Er verfolgt nicht in erster Linie eigenwirtschaftliche Zwecke.
