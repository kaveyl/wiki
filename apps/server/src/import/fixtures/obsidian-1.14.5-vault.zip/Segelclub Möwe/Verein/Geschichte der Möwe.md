# Geschichte der Möwe

1962 gründeten sieben Freunde den Club in einem ==alten Bootsschuppen==. Den Zweck regelt die Satzung:

![[Satzung#§ 2 Zweck]]

Ein Blick vom Steg im Herbst:

![[../Anhänge/Fotos/Steg im Herbst.jpg|300]]

Das erste Clubboot war die [[Möwe I]]. %%Baujahr unsicher, 1958 oder 1959?%%

> [!quote] Gründungsprotokoll
> „Wir wollen segeln, nicht reden.“
> — aus dem ersten Protokoll

> [!example]- Zeitleiste (zum Aufklappen)
> - 1962 Gründung
> - 1975 Clubhaus
> - 1999 ==Jugendabteilung==
> - 2026 Neuer Steg

%%
Mehrzeiliger Kommentar:
Fotos aus dem Archiv fehlen noch.
Bitte bei der Chronik nachfragen.
%%

Mehr dazu in [[../Hafen/Clubhaus/Küche und Bar]].

Eingefügtes Bild: ![[Pasted image 20261028222557.png]]
