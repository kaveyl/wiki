# Vorstandssitzung März 2025

## Beschlüsse

- Steg wird 2026 erneuert.
- Herbstpokal 2025 findet statt: [[Regatten/2025/Herbstpokal]].
