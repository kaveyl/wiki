# Mitglieder & Beiträge

## Beitragsordnung

| Gruppe | Beitrag pro Jahr | Aufnahmegebühr |
|:--|--:|:-:|
| Erwachsene | 180 € | 50 € |
| Jugend (bis 18) | 60 € | – |
| Familien | 290 € | 80 € |
| Fördermitglieder | 40 € | – |

Der Jahresbeitrag für eine Familie mit $n$ Kindern beträgt $B = 290 + 0 \cdot n$ Euro.

$$
\text{Liegeplatz} = 12\,\frac{\text{€}}{\text{m}} \times L_{\text{Boot}}
$$

## Zahlungsweise

Lastschrift im März. Beschluss dazu: [[Verein/Vorstand/Protokolle/2026/Protokoll März#^beschluss-beitrag]].

#finanzen
