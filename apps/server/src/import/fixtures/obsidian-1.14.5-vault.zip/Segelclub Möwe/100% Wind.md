# 100% Wind

| Bft | Bezeichnung | kn |
|---|---|---|
| 4 | mäßig | 11–16 |
| 6 | stark | 22–27 |
| 8 | stürmisch | 34–40 |
