# Wetterkunde

## Wolken

Cumulonimbus = Gewitterwolke. #wetter

## Gewitter

> [!danger] Lebensgefahr
> Mast ist ein Blitzableiter.

## Wind

Beaufort-Skala: siehe [[100% Wind]].
