# Kreuzknoten

Verbindet zwei gleich starke Leinen. #knoten

Übersicht: [Manöver](../Manöver.md#Knoten)
