# Schotstek

Verbindet zwei unterschiedlich starke Leinen. #knoten

Übersicht: [Manöver](../Manöver.md#Knoten)
