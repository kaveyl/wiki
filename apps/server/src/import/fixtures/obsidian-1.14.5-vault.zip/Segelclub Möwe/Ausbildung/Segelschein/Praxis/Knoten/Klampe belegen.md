# Klampe belegen

Einmal rund, zwei Kreuzschläge, Kopfschlag. #knoten

Übersicht: [[Manöver#Knoten]]
