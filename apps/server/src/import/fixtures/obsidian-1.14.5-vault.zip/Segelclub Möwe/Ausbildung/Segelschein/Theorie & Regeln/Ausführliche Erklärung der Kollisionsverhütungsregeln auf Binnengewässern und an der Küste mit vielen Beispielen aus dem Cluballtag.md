# Ausführliche Erklärung

Ein sehr langer Dateiname, wie ihn manche Leute vergeben. Zurück: [[Vorfahrtsregeln#Grundregeln]].
