# Vorfahrtsregeln

## Grundregeln

1. Backbordbug vor Steuerbordbug ausweichen.
2. Luv weicht Lee.
3. Überholer hält sich frei.

## Ausnahmen

Berufsschifffahrt hat immer Vorrang. Ausführlich: [[Ausführliche Erklärung der Kollisionsverhütungsregeln auf Binnengewässern und an der Küste mit vielen Beispielen aus dem Cluballtag]].
