# Palstek

Der König der Knoten: eine feste Schlaufe. #knoten

Übersicht: [[Manöver#Knoten]]
