# Manöver

## Wende

Mit dem Bug durch den Wind. Regeln: [Vorfahrtsregeln](../Theorie%20&%20Regeln/Vorfahrtsregeln.md#Grundregeln).

## Halse

Mit dem Heck durch den Wind – Vorsicht, der Baum schlägt um! ==Kopf einziehen.==

## Kenterung

Siehe [Was tun bei Kenterung?](../../../Was%20tun%20bei%20Kenterung?.md) und den Abschnitt [weiter oben](#Wende).

## Knoten

- [Palstek](Knoten/Palstek.md)
- [Achtknoten](Knoten/Achtknoten.md)
- [Webeleinstek](Knoten/Webeleinstek.md)
- [Klampe](Knoten/Klampe%20belegen.md)
- Noch offen: [Schotstek doppelt](Knoten/Schotstek%20doppelt.md)

Bild der Wende: ![](../../../Anhänge/Fotos/Steg%20im%20Herbst.jpg)

Eingefügtes Bild: ![](../../../Anhänge/Pasted%20image%2020261028222612.png)
