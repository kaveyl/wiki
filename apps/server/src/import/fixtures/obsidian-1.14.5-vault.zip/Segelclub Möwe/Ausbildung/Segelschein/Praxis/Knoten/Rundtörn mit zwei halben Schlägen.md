# Rundtörn mit zwei halben Schlägen

Hält auch unter Last. #knoten

Übersicht: [[Manöver#Knoten]]
