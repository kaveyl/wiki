# Achtknoten

Stopperknoten am Ende der Schot. #knoten

Übersicht: [Manöver](../Manöver.md#Knoten)
