# Opti-Kurs

Für Kinder ab 7 Jahren. #boot

Von Hand getippt: [[Checkliste]], [[Theorie & Regeln/Wetterkunde]], [[Segelschein/Praxis/Manöver#Wende]].
