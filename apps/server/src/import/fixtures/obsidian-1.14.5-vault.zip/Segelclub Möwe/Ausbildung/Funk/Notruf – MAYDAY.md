# Notruf – MAYDAY

> [!important] Wortlaut
> MAYDAY MAYDAY MAYDAY, hier ist Segelyacht Möwe II …

<details>
<summary>Buchstabiertafel</summary>

A = Alfa, B = Bravo, C = Charlie

</details>

<span style="color: red">Nur im Notfall!</span>
