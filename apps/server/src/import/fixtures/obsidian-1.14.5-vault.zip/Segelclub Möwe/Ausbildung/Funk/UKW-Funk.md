# UKW-Funk

Kanal 16 = Not- und Anrufkanal. Siehe [[Notruf – MAYDAY]].
