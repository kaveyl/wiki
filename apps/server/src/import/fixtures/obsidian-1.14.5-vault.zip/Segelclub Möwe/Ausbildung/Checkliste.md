# Checkliste Ausbildung

- [ ] Theorie: [[Segelschein/Theorie & Regeln/Vorfahrtsregeln]]
- [ ] Theorie: [[Segelschein/Theorie & Regeln/Wetterkunde]]
- [ ] Knoten: [[Palstek]], [[Achtknoten]]
- [ ] Funk: [[Notruf – MAYDAY]]
