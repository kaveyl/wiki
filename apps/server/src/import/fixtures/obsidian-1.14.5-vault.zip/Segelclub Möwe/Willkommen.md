---
aliases:
  - Start
  - Startseite
tags:
  - verein
  - wichtig
cssclasses:
  - breit
---
# Willkommen beim Segelclub Möwe

Der Club besteht seit 1962 am Ufer des Mühlsees. ![[logo.svg]]

## Schnellzugriff

- Vereinsleben: [[Satzung]], [[Geschichte der Möwe|unsere Geschichte]], [[Fragen & Antworten]]
- Boote: [[Optimist]], [[Boote/Kielboote/Möwe II]], [[Boote/Wartung/Checkliste]]
- Termine: [[Feste/Sommerfest 2026]] und [[Frühjahrsregatta#Meldeschluss]]
- Ausbildung: [[Ausbildung/Segelschein/Theorie & Regeln/Vorfahrtsregeln#Grundregeln|Vorfahrt in Kürze]]
- Sonderfälle: [[Was tun bei Kenterung?]], [[Grillabend #3]], [[100% Wind]]
- Noch nicht geschrieben: [[Regatta 2027]] und [[Boote/Möwe III]]
- Gleicher Name, zwei Jahre: [[Verein/Vorstand/Protokolle/2026/Protokoll März]] und [[Verein/Vorstand/Protokolle/2025/Protokoll März]]

Zum Abschnitt weiter unten: [[#Kontakt]] bzw. [[#Kontakt|schreib uns]].

> [!note]
> Neue Mitglieder melden sich bitte beim Vorstand. #verein #mitglieder/neu

> [!tip] Tipp für Gäste
> Schwimmwesten liegen im Bootshaus, Regal links.

## Kontakt

Mail an [vorstand@moewe.invalid](mailto:vorstand@moewe.invalid) oder https://moewe.invalid/kontakt

---

%% Interner Hinweis: Startseite einmal im Jahr prüfen. %%

Eingefügtes Bild: ![[Pasted image 20261028222554.png]]

Planung: [[Saisonplanung.canvas]]
