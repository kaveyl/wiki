# Was tun bei Kenterung?

1. Ruhe bewahren.
2. Beim Boot bleiben.
3. Aufrichten, siehe [[Manöver]].
