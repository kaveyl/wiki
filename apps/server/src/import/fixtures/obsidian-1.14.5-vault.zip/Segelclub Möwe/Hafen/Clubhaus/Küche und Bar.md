# Küche & Bar

Getränkepreise hängen aus. Schlüssel: [Schlüssel](Schlüssel.md).

Geschichte: [Geschichte der Möwe](../../Verein/Geschichte%20der%20Möwe.md#Geschichte%20der%20Möwe).

Der Antrag zum Ausdrucken: [](../../Anhänge/Mitgliedsantrag.docx).
