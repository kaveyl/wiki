# Bojenfeld

Zwölf Bojen, Abstand 25 m. Gleiche Seite wie [[Hafen/Liegeplätze]] – dieser Wiki-Link wurde von Hand getippt, obwohl Markdown-Links eingestellt sind.
