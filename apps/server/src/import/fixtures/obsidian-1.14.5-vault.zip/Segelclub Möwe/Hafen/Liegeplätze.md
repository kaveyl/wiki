# Liegeplätze

| Steg | Plätze | Frei |
|---|---|---|
| A | 12 | 2 |
| B | 8 | 0 |

Kosten: [Mitglieder & Beiträge](../Verein/Vorstand/Mitglieder%20&%20Beiträge.md#Beitragsordnung).
Anfahrt: [Straße zum Hafen](Straße%20zum%20Hafen.md). Hafenordnung: [Hafenordnung](Hafenordnung.md) (gibt es noch nicht).

Eingefügtes Bild: ![](Bilder/Pasted%20image%2020261028222616.png)
