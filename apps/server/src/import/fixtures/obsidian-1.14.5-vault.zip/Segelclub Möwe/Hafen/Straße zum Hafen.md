# Straße zum Hafen

Über die Seestraße, dann links in den Möwenweg. Parken am [Küche und Bar](Clubhaus/Küche%20und%20Bar.md).

![](../Anhänge/logo.svg)
