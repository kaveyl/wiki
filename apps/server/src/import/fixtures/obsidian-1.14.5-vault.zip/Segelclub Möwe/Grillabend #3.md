# Grillabend #3

Der dritte Grillabend, Rauten im Namen. Gehört zum [[Feste/Sommerfest 2026]]. #feste
