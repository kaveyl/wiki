# Checkliste Bootswartung

## Vor jeder Ausfahrt

- [ ] Lenzpumpe prüfen
- [ ] Schoten auf Scheuerstellen ansehen
- [x] Paddel an Bord

## Nach der Saison

Siehe [[Antifouling]].
