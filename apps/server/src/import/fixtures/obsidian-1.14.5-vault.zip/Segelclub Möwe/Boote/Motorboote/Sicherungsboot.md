# Sicherungsboot

Schlauchboot mit 15 PS für die Regatten. #boot
