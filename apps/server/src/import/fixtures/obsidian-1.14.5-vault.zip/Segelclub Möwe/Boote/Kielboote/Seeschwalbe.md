# Seeschwalbe

Leihboot eines Mitglieds. Bild vom Kauf:

![[animiert.gif]]
