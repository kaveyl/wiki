# Folkeboot

Nordisches Folkeboot, Klinker. #boot

Alle Boote: ![[Bootsliste.base]]
