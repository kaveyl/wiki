# Kran & Termine

| Boot | Kran raus | Kran rein |
|---|---|---|
| [[../../Kielboote/Möwe II]] | 25.10. | 12.04. |
| [[Seeschwalbe]] | 26.10. | 13.04. |

```mermaid
gantt
    title Winterlager
    dateFormat YYYY-MM-DD
    Kran raus      :a1, 2026-10-25, 2d
    Antifouling    :a2, 2027-03-01, 14d
    Kran rein      :a3, 2027-04-12, 2d
```
