---
baujahr: 1988
länge: 7.5
typ: Kielboot
heimathafen: "[[Liegeplätze]]"
vorgaenger: "[[Möwe I]]"
tags:
  - boot/kielboot
---
# Möwe II

Kielboot, 7,5 m, Baujahr 1988. Wird im Winter gekrant: [[Kran & Termine]]. #boot/kielboot

Vorgängerin: [[Möwe I]].

## Ausrüstung

- Rettungsinsel
- UKW-Funk, siehe [[UKW-Funk]]
