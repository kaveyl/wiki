# Antifouling

> [!caution] Giftig
> Nur mit Schutzhandschuhen und Maske.

Reihenfolge: schleifen → grundieren → zwei Schichten. Zurück zur [[Boote/Wartung/Checkliste]].
