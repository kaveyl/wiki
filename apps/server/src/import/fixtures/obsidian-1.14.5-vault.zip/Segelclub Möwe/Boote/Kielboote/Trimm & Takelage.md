# Trimm & Takelage

Achterstag dichter bei mehr Wind, siehe [100% Wind](../../100%%20Wind.md). Für die [Möwe II](Möwe%20II.md) gilt Mastfall 30 cm.
