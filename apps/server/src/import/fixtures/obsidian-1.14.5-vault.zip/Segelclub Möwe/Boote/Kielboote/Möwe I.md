# Möwe I

Das erste Clubboot, Baujahr 1959. Heute Museumsstück im [[../../Hafen/Clubhaus/Küche und Bar|Clubhaus]]. #boot/kielboot

Nachfolgerin: [[Möwe II]].
