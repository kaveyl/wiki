# Laser

Einhand-Jolle, olympisch bis 2024. Gewicht 59 kg. #boot/jolle

Mehr zur Ausbildung: [[Ausbildung/Checkliste|Checkliste der Ausbildung]].
