---
aliases: Opti
anzahl: 6
---
# Optimist

Einhand-Jolle für Kinder bis 15. Der Club hat sechs davon. #boot/jolle #jugend

![[bild-test.png|Segelzeichen]]

Pflege: [[Boote/Wartung/Checkliste#Vor jeder Ausfahrt]].
Gleiche Liste für die Regatta: [[Regatten/Checkliste]].
