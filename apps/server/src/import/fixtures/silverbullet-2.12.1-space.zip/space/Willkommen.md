---
tags: start
---
# Willkommen beim Wanderverein Alpenrose
Wir wandern seit 1987. ![Logo](Medien/logo.svg)

Zu den [[Touren/2026/Tourenplan]] und zum [[Vorstand/Protokoll|letzten Protokoll]].
Siehe auch [[Touren/2026/Tourenplan#Termine]] und [[Gibt es nicht]].

> **note** Hinweis
> Neue Mitglieder sind willkommen.

> **warning** Achtung
> Steinschlaggefahr.

${template.each(query[[from index.tag "page" where _.tags == "hütte" limit 3]], templates.pageItem)}
