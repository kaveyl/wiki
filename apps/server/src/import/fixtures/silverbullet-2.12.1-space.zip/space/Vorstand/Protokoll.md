# Protokoll März
Anwesend: 7. Nächstes: [[Archiv/2019/Protokoll]].
