```lua
local hm = function(a, b) return math.abs(b - a) end
```

```space-lua
-- priority: 10
function hallo() return 'Grüß Gott' end
```

${hallo()}

Inline $E = mc^2$

```mermaid
graph TD
  A --> B
```

==markiert== und `[[kein Link]]` im Code.
