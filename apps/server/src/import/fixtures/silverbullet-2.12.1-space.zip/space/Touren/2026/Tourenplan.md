---
tags:
  - touren
  - "2026"
leitung: Anna-Lena
---
# Termine
| Datum | Ziel | Höhe |
|---|---|---:|
| 12.06. | Großglockner-Blick | 2.571 m |
| 03.07. | Dachstein | 2.995 m |

![Gipfel](../../Medien/foto-berg.jpg)
![[Medien/bild-test.png]]

Der Plan als PDF: [Tourenplan 2026.pdf](Tourenplan%202026.pdf)

Attribute im Text: [schwierigkeit: mittel] [dauer: 6h] #wichtig #[[zwei Wörter]]

* [ ] Bus bestellen [due: 2026-06-01]
* [x] Hütte reservieren
* [TODO] Wetter prüfen

Eingebettet: ![[Touren/Sommer/Dachstein Südwand]]
