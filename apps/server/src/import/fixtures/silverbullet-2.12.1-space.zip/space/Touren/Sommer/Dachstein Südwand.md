# Dachstein Südwand
Schwierigkeit **C**. Zurück zum [[Touren/2026/Tourenplan|Plan]].
![](../../Medien/animiert.gif)
