---
tags: hütte
region: Salzburg
---
# Hütte 5
Lage: 1385 m. #übernachtung

Vorher: [[Hütten/Hütte 4]]
