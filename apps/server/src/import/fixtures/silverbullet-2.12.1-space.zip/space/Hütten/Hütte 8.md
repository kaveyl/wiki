---
tags: hütte
region: Tirol
---
# Hütte 8
Lage: 1496 m. #übernachtung

Vorher: [[Hütten/Salzburg/Hütte 7]]
