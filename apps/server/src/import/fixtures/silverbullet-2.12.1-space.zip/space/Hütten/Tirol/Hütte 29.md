---
tags: hütte
region: Salzburg
---
# Hütte 29
Lage: 2273 m. #übernachtung

Vorher: [[Hütten/Hütte 28]]
