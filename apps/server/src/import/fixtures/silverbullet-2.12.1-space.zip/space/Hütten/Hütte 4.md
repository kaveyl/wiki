---
tags: hütte
region: Tirol
---
# Hütte 4
Lage: 1348 m. #übernachtung

Vorher: [[Hütten/Salzburg/Hütte 3]]
