---
tags: hütte
region: Salzburg
---
# Hütte 13
Lage: 1681 m. #übernachtung

Vorher: [[Hütten/Hütte 12]]
