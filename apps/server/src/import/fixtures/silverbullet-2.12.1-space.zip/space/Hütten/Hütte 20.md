---
tags: hütte
region: Tirol
---
# Hütte 20
Lage: 1940 m. #übernachtung

Vorher: [[Hütten/Salzburg/Hütte 19]]
