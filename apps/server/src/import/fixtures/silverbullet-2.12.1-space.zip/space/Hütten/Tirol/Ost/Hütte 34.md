---
tags: hütte
region: Kärnten
---
# Hütte 34
Lage: 2458 m. #übernachtung

Vorher: [[Hütten/Tirol/Hütte 33]]
