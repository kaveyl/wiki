---
tags: hütte
region: Kärnten
---
# Hütte 18
Lage: 1866 m. #übernachtung

Vorher: [[Hütten/Tirol/Hütte 17]]
