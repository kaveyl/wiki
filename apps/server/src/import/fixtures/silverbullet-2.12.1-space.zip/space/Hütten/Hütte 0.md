---
tags: hütte
region: Tirol
---
# Hütte 0
Lage: 1200 m. #übernachtung
