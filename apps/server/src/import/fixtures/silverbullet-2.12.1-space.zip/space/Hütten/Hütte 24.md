---
tags: hütte
region: Tirol
---
# Hütte 24
Lage: 2088 m. #übernachtung

Vorher: [[Hütten/Salzburg/Hütte 23]]
