---
tags: hütte
region: Tirol
---
# Hütte 28
Lage: 2236 m. #übernachtung

Vorher: [[Hütten/Salzburg/Hütte 27]]
