---
tags: hütte
region: Steiermark
---
# Hütte 11
Lage: 1607 m. #übernachtung

Vorher: [[Hütten/Tirol/Ost/Hütte 10]]
