---
tags: hütte
region: Kärnten
---
# Hütte 14
Lage: 1718 m. #übernachtung

Vorher: [[Hütten/Tirol/Hütte 13]]
