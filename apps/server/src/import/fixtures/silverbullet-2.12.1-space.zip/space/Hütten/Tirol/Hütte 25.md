---
tags: hütte
region: Salzburg
---
# Hütte 25
Lage: 2125 m. #übernachtung

Vorher: [[Hütten/Hütte 24]]
