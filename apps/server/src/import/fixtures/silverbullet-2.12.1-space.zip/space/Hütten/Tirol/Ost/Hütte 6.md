---
tags: hütte
region: Kärnten
---
# Hütte 6
Lage: 1422 m. #übernachtung

Vorher: [[Hütten/Tirol/Hütte 5]]
