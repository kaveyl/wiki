---
tags: hütte
region: Steiermark
---
# Hütte 31
Lage: 2347 m. #übernachtung

Vorher: [[Hütten/Tirol/Ost/Hütte 30]]
