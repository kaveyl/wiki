---
tags: hütte
region: Salzburg
---
# Hütte 33
Lage: 2421 m. #übernachtung

Vorher: [[Hütten/Hütte 32]]
