---
tags: hütte
region: Salzburg
---
# Hütte 9
Lage: 1533 m. #übernachtung

Vorher: [[Hütten/Hütte 8]]
