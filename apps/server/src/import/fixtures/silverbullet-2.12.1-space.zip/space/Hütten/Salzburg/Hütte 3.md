---
tags: hütte
region: Steiermark
---
# Hütte 3
Lage: 1311 m. #übernachtung

Vorher: [[Hütten/Tirol/Ost/Hütte 2]]
