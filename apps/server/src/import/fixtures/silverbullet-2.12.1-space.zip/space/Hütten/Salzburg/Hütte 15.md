---
tags: hütte
region: Steiermark
---
# Hütte 15
Lage: 1755 m. #übernachtung

Vorher: [[Hütten/Tirol/Ost/Hütte 14]]
