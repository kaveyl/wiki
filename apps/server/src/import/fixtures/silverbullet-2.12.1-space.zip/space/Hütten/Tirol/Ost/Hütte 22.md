---
tags: hütte
region: Kärnten
---
# Hütte 22
Lage: 2014 m. #übernachtung

Vorher: [[Hütten/Tirol/Hütte 21]]
