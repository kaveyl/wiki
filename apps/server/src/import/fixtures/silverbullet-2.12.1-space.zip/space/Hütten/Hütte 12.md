---
tags: hütte
region: Tirol
---
# Hütte 12
Lage: 1644 m. #übernachtung

Vorher: [[Hütten/Salzburg/Hütte 11]]
