---
tags: hütte
region: Steiermark
---
# Hütte 23
Lage: 2051 m. #übernachtung

Vorher: [[Hütten/Tirol/Ost/Hütte 22]]
