---
tags: hütte
region: Kärnten
---
# Hütte 2
Lage: 1274 m. #übernachtung

Vorher: [[Hütten/Tirol/Hütte 1]]
