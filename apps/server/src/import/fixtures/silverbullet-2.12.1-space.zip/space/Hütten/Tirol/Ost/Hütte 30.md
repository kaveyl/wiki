---
tags: hütte
region: Kärnten
---
# Hütte 30
Lage: 2310 m. #übernachtung

Vorher: [[Hütten/Tirol/Hütte 29]]
