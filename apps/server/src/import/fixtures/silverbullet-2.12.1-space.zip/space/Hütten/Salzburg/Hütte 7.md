---
tags: hütte
region: Steiermark
---
# Hütte 7
Lage: 1459 m. #übernachtung

Vorher: [[Hütten/Tirol/Ost/Hütte 6]]
