---
tags: hütte
region: Tirol
---
# Hütte 32
Lage: 2384 m. #übernachtung

Vorher: [[Hütten/Salzburg/Hütte 31]]
