---
tags: hütte
region: Steiermark
---
# Hütte 27
Lage: 2199 m. #übernachtung

Vorher: [[Hütten/Tirol/Ost/Hütte 26]]
