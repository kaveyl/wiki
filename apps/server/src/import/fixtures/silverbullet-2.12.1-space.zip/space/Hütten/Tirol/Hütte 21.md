---
tags: hütte
region: Salzburg
---
# Hütte 21
Lage: 1977 m. #übernachtung

Vorher: [[Hütten/Hütte 20]]
