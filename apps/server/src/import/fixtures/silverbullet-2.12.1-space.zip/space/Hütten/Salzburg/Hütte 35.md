---
tags: hütte
region: Steiermark
---
# Hütte 35
Lage: 2495 m. #übernachtung

Vorher: [[Hütten/Tirol/Ost/Hütte 34]]
