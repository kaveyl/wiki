---
tags: hütte
region: Tirol
---
# Hütte 16
Lage: 1792 m. #übernachtung

Vorher: [[Hütten/Salzburg/Hütte 15]]
