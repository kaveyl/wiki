Schnell notiert.
