Sonderzeichen im Namen. [[Größe & Gewicht (50 l) – Test]]
