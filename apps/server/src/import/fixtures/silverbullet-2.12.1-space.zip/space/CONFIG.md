This is where you configure SilverBullet.

```space-lua
config.set("plugs", {})
config.set("shortcuts", {})
```
