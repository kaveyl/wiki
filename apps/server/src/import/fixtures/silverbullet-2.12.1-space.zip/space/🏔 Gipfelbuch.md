Emoji im Namen.
