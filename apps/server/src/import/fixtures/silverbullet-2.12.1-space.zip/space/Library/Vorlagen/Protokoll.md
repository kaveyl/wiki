---
tags: meta/template/page
suggestedName: "Protokolle/${date.today()}"
---
# Protokoll ${date.today()}

Anwesend:
