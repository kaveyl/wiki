# Speisekarte

Gleicher Titel wie in der ersten Sammlung.