# Sicherheitsunterweisung

Vierte Ebene unter Team-Handbuch → Einarbeitung → Erste Woche → Tag 1.


1. Notausgänge zeigen
2. Feuerlöscher (CO₂) erklären
3. [Reinigungsplan](./../../../../R%C3%B6sterei%20&%20Produktion/Maschinen%20&%20Wartung/Reinigungsplan.md) durchgehen

Siehe auch [Willkommen bei Bohnenglück](./../../../Willkommen%20bei%20Bohnengl%C3%BCck.md).