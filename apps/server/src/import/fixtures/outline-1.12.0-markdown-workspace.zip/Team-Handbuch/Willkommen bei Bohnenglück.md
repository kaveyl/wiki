# 👋 Willkommen bei Bohnenglück

Schön, dass du da bist! Ansprechpartner: @[Rita Röstmeister](mention://89e3f92c-c6c7-4c25-89ce-b32f58239856/user/80397680-792f-498c-8437-3bcaa0a6b688) und @[Bruno Bohne](mention://0bf74f15-90a1-4a6e-9b6f-3f9d8daf461d/user/b5f95c2b-636b-4f59-81e7-314fe5118cc0).

 ![Logo Bohnenglück](uploads/80397680-792f-498c-8437-3bcaa0a6b688/46461815-5ff6-4795-ae6c-d1d1fa018f7c/Logo%20Bohnengl%C3%BCck.svg)


:::info
Bitte lies zuerst die [Sicherheitsunterweisung](./Einarbeitung/Erste%20Woche/Tag%201/Sicherheitsunterweisung.md).

:::


:::warning
Die Röster werden heiß – **nie** ohne Handschuhe anfassen.

:::


:::success
Nach der ersten Woche gibt es eine Tüte Hausmischung.

:::


:::tip
Fragen? Schreib @[Bruno Bohne](mention://2cbf1450-dc8e-4d62-b03a-22bd9577dc27/user/b5f95c2b-636b-4f59-81e7-314fe5118cc0) an.

:::