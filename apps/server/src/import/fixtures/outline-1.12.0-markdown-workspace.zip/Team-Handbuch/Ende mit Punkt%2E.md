# Ende mit Punkt.

Randfall Titel 'Ende mit Punkt.'.