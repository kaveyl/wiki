# Schichtplan

| Tag | Früh | Spät |
|-----|------|------|
| Mo  | Rita Röstmeister | Bruno Bohne |
| Di  | Bruno Bohne | Rita Röstmeister |
| Mi  | –    | –    |

Tabelle mit `Code` und **fett** in Zellen: | Pipe | im Text |