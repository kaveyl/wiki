# Hausmischung „Bohnenglück“

40 % Brasilien, 40 % Äthiopien, 20 % Robusta. **Geheim!**