# Verkostung „Äthiopien“

Verkostung mit Kaffee aus [Yirgacheffe](./../../R%C3%B6sterei%20&%20Produktion/R%C3%B6stprofile/%C3%84thiopien/Yirgacheffe.md) (andere Sammlung).