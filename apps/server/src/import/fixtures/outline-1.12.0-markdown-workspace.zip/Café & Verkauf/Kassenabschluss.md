# Kassenabschluss

Abläufe beim Kassenabschluss:

- [x] Bon-Rolle prüfen
- [ ] Bargeld zählen
  - [ ] Scheine
  - [x] Münzen
- [ ] Z-Bericht drucken

> Der Abschluss muss vor 19:00 Uhr fertig sein. — Rita