# Speisekarte

![Logo Bohnenglück](uploads/80397680-792f-498c-8437-3bcaa0a6b688/46461815-5ff6-4795-ae6c-d1d1fa018f7c/Logo%20Bohnengl%C3%BCck.svg)

| Getränk | Preis (€) |
|---------|----------:|
| Espresso | 2,40      |
| Cappuccino | 3,60      |
| Filterkaffee „Haus“ | 3,10      |

Mehr zu [Heißgetränke](./Speisekarte/Hei%C3%9Fgetr%C3%A4nke.md) und [Kuchen](./Speisekarte/Kuchen.md).