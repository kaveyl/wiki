# Größe & Maße: Verpackung

Größen: 250 g, 500 g & 1 kg. Maße: 12 × 8 × 20 cm.