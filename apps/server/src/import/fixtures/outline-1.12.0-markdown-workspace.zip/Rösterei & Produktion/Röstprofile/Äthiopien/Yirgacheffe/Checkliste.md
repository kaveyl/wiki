# Checkliste

Checkliste nach dem Rösten (gleicher Titel, gleiche Ebene):

- [ ] Kühlsieb leeren
- [ ] Silberhäutchen entsorgen
- [x] Charge eintragen