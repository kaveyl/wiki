# Checkliste

Checkliste vor dem Rösten (erste Fassung):

- [x] Trommel leer
- [x] Abluft offen
- [ ] Waage geeicht