# Messwerte: Charge 12/2026

Messwerte der Charge 12/2026.

| Minute | Temperatur (°C) | Bemerkung |
|--------|-----------------|-----------|
| 0      | 200             | Einfüllen |
| 4      | 152             | Gelbphase |
| 8:30   | 196             | First Crack |
| 11     | 208             | Ende      |

Zurück zur [Röstkurve](./../R%C3%B6stkurve%20Charge%2012.md) bzw. direkt zum Abschnitt [Ablauf](./../R%C3%B6stkurve%20Charge%2012.md#h-ablauf).