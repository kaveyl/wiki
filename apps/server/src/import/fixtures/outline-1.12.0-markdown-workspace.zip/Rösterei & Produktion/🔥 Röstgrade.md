# 🔥 Röstgrade

Der Titel dieser Seite beginnt mit einem Emoji (ohne Outline-Icon).

| Röstgrad | Farbe | Geschmack |
|:---------|:-----:|----------:|
| Hell     | Zimt  | fruchtig  |
| Mittel   | Kastanie | ausgewogen |
| Dunkel   | Schokolade | kräftig   |


:::tip
Für Espresso eher **mittel bis dunkel** rösten.

:::