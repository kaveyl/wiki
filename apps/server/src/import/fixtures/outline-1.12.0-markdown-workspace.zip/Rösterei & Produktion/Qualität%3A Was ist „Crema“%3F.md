# Qualität: Was ist „Crema“?

Die Crema ist der Schaum auf dem Espresso. Frage: *Wie dick?* – 3–4 mm.