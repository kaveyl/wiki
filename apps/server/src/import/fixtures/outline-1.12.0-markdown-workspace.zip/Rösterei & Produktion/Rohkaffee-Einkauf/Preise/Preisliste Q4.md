# Preisliste Q4

| Herkunft | €/kg |
|----------|-----:|
| Brasilien | 6,80 |
| Äthiopien | 9,20 |