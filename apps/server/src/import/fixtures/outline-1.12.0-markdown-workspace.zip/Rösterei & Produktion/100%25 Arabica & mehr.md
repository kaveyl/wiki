# 100% Arabica & mehr

Nur 100% Arabica & ein bisschen Robusta für die Crema.