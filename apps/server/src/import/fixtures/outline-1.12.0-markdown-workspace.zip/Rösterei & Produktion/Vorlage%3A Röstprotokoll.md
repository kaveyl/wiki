# Vorlage: Röstprotokoll

## Röstprotokoll

| Feld | Wert |
|------|------|
| Datum |      |
| Herkunft |      |
| Gewicht |      |

- [ ] Röstgrad geprüft
- [ ] Probe abgefüllt