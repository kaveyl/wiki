# #1 Bestseller

Unser Bestseller ist die [Hausmischung](./../Geheimrezepturen/Hausmischung%20%E2%80%9EBohnengl%C3%BCck%E2%80%9C.md) (Link in die private Sammlung).