# ☕ Kaffeesorten

Diese Seite hat das Icon ☕ (Outline-Icon, nicht im Titel).

* Arabica
  * Äthiopien: siehe [Äthiopien](./R%C3%B6stprofile/%C3%84thiopien.md)
  * Brasilien: siehe [Brasilien](./R%C3%B6stprofile/Brasilien.md)
* Robusta

Erwähnung einer Seite: [#1 Bestseller](./#1%20Bestseller.md)