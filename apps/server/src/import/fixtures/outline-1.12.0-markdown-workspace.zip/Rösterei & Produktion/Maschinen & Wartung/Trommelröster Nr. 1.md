# Trommelröster Nr. 1

Seite **Trommelröster Nr. 1** der Kaffeerösterei Bohnenglück. Übergeordnet: [Maschinen & Wartung](./../Maschinen%20&%20Wartung.md).

* Punkt eins
* Punkt zwei