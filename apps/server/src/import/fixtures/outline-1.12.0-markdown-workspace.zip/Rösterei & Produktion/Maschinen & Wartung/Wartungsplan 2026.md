# Wartungsplan 2026

Plan für 2026. Datei:

[Röstplan Oktober.pdf 589](uploads/80397680-792f-498c-8437-3bcaa0a6b688/fc68f8bd-ed56-4570-b424-02e745f4d3f2/R%C3%B6stplan%20Oktober.pdf)

Siehe auch [Trommelröster](./Trommelr%C3%B6ster%20Nr.%201.md).