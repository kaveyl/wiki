---
type: Document
title: Hausmischung „Bohnenglück“
description: 40 % Brasilien, 40 % Äthiopien, 20 % Robusta. Geheim!
resource: http://127.0.0.1:8101/doc/hausmischung-bohnengluck-jSCJ7px81O
status: stable
generated:
  by: human:rita@bohnenglueck.test
  at: '2026-10-28T21:30:48.758Z'
---

# Hausmischung „Bohnenglück“

40 % Brasilien, 40 % Äthiopien, 20 % Robusta. **Geheim!**