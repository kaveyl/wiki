---
type: Document
title: Winterröstung
description: Seite Winterröstung der Kaffeerösterei Bohnenglück.
resource: http://127.0.0.1:8101/doc/winterrostung-3af6Q22aZT
status: stable
generated:
  by: human:rita@bohnenglueck.test
  at: '2026-10-28T21:30:48.771Z'
---

# Winterröstung

Seite **Winterröstung** der Kaffeerösterei Bohnenglück.

* Punkt eins
* Punkt zwei