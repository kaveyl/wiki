---
type: Document
title: Preise
description: 'Seite Preise der Kaffeerösterei Bohnenglück. Übergeordnet: Rohkaffee-Einkauf.'
resource: http://127.0.0.1:8101/doc/preise-4OEW3MSseT
status: stable
generated:
  by: human:rita@bohnenglueck.test
  at: '2026-10-28T21:30:48.223Z'
---

# Preise

Seite **Preise** der Kaffeerösterei Bohnenglück. Übergeordnet: [Rohkaffee-Einkauf](./../Rohkaffee-Einkauf.md).

* Punkt eins
* Punkt zwei