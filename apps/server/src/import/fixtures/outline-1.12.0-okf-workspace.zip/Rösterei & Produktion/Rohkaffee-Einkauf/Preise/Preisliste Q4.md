---
type: Document
title: Preisliste Q4
description: Herkunft
resource: http://127.0.0.1:8101/doc/preisliste-q4-hKlO7l9ays
status: stable
generated:
  by: human:rita@bohnenglueck.test
  at: '2026-10-28T21:30:48.241Z'
---

# Preisliste Q4

| Herkunft | €/kg |
|----------|-----:|
| Brasilien | 6,80 |
| Äthiopien | 9,20 |