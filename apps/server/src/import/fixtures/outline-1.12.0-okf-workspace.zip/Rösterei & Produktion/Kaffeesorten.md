---
type: Document
title: Kaffeesorten
description: Diese Seite hat das Icon ☕ (Outline-Icon, nicht im Titel).
resource: http://127.0.0.1:8101/doc/kaffeesorten-QXagU9mSvZ
status: stable
generated:
  by: human:rita@bohnenglueck.test
  at: '2026-10-28T21:30:48.014Z'
---

# ☕ Kaffeesorten

Diese Seite hat das Icon ☕ (Outline-Icon, nicht im Titel).

* Arabica
  * Äthiopien: siehe [Äthiopien](./R%C3%B6stprofile/%C3%84thiopien.md)
  * Brasilien: siehe [Brasilien](./R%C3%B6stprofile/Brasilien.md)
* Robusta

Erwähnung einer Seite: [#1 Bestseller](./#1%20Bestseller.md)