---
type: Document
title: Brasilien
description: 'Seite Brasilien der Kaffeerösterei Bohnenglück. Übergeordnet: Röstprofile.'
resource: http://127.0.0.1:8101/doc/brasilien-5s6N2IQ7ph
status: stable
generated:
  by: human:rita@bohnenglueck.test
  at: '2026-10-28T21:30:47.942Z'
---

# Brasilien

Seite **Brasilien** der Kaffeerösterei Bohnenglück. Übergeordnet: [Röstprofile](./../R%C3%B6stprofile.md).

* Punkt eins
* Punkt zwei