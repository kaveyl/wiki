---
type: Document
title: 'Messwerte: Charge 12/2026'
description: Messwerte der Charge 12/2026.
resource: http://127.0.0.1:8101/doc/messwerte-charge-122026-hbl1JSMkkY
status: stable
generated:
  by: human:rita@bohnenglueck.test
  at: '2026-10-28T21:30:47.874Z'
---

# Messwerte: Charge 12/2026

Messwerte der Charge 12/2026.

| Minute | Temperatur (°C) | Bemerkung |
|--------|-----------------|-----------|
| 0      | 200             | Einfüllen |
| 4      | 152             | Gelbphase |
| 8:30   | 196             | First Crack |
| 11     | 208             | Ende      |

Zurück zur [Röstkurve](./../R%C3%B6stkurve%20Charge%2012.md) bzw. direkt zum Abschnitt [Ablauf](./../R%C3%B6stkurve%20Charge%2012.md#h-ablauf).