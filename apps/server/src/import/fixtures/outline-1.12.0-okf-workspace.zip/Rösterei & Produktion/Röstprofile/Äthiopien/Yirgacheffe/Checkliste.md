---
type: Document
title: Checkliste
description: 'Checkliste nach dem Rösten (gleicher Titel, gleiche Ebene):'
resource: http://127.0.0.1:8101/doc/checkliste-taWdlP3Hdb
status: stable
generated:
  by: human:rita@bohnenglueck.test
  at: '2026-10-28T21:30:47.909Z'
---

# Checkliste

Checkliste nach dem Rösten (gleicher Titel, gleiche Ebene):

- [ ] Kühlsieb leeren
- [ ] Silberhäutchen entsorgen
- [x] Charge eintragen