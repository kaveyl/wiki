---
type: Document
title: Checkliste
description: 'Checkliste vor dem Rösten (erste Fassung):'
resource: http://127.0.0.1:8101/doc/checkliste-HjIy7rygSw
status: stable
generated:
  by: human:rita@bohnenglueck.test
  at: '2026-10-28T21:30:47.892Z'
---

# Checkliste

Checkliste vor dem Rösten (erste Fassung):

- [x] Trommel leer
- [x] Abluft offen
- [ ] Waage geeicht