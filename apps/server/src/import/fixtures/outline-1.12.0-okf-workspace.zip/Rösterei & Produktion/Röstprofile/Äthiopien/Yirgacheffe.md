---
type: Document
title: Yirgacheffe
description: 'Seite Yirgacheffe der Kaffeerösterei Bohnenglück. Übergeordnet: Äthiopien.'
resource: http://127.0.0.1:8101/doc/yirgacheffe-pKcq8H6u0f
status: stable
generated:
  by: human:rita@bohnenglueck.test
  at: '2026-10-28T21:30:47.835Z'
---

# Yirgacheffe

Seite **Yirgacheffe** der Kaffeerösterei Bohnenglück. Übergeordnet: [Äthiopien](./../%C3%84thiopien.md).

* Punkt eins
* Punkt zwei