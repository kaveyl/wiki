---
type: Document
title: Röstkurve Charge 12
description: Die Röstkurve der Charge 12 (Yirgacheffe, hell).
resource: http://127.0.0.1:8101/doc/rostkurve-charge-12-PgLvncaUeH
status: stable
generated:
  by: human:rita@bohnenglueck.test
  at: '2026-10-28T21:30:47.854Z'
---

# Röstkurve Charge 12

Die Röstkurve der Charge 12 (Yirgacheffe, hell).

 ![Röstkurve Charge 12](uploads/80397680-792f-498c-8437-3bcaa0a6b688/a9ceda5e-7057-48c6-acc1-6c41840203b1/R%C3%B6stkurve%20Charge%2012.png)

## Ablauf


1. Vorheizen auf 200 °C
2. Bohnen einfüllen (12 kg)
3. First Crack nach 8:30 min

## Röstgrad prüfen

Farbe mit der Karte vergleichen, siehe [Röstgrade](./../../../%F0%9F%94%A5%20R%C3%B6stgrade.md).

## Schritt 2: Abkühlen

Kühlsieb 4 Minuten laufen lassen. Messwerte stehen in [Messwerte: Charge 12/2026](./R%C3%B6stkurve%20Charge%2012/Messwerte%253A%20Charge%2012%252F2026.md).