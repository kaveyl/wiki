---
type: Document
title: Äthiopien
description: 'Seite Äthiopien der Kaffeerösterei Bohnenglück. Übergeordnet: Röstprofile.'
resource: http://127.0.0.1:8101/doc/athiopien-3gdSKd7LE9
status: stable
generated:
  by: human:rita@bohnenglueck.test
  at: '2026-10-28T21:30:47.815Z'
---

# 🇪🇹 Äthiopien

Seite **Äthiopien** der Kaffeerösterei Bohnenglück. Übergeordnet: [Röstprofile](./../R%C3%B6stprofile.md).

* Punkt eins
* Punkt zwei