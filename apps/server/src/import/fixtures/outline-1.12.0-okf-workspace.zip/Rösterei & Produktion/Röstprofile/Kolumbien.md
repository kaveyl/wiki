---
type: Document
title: Kolumbien
description: 'Seite Kolumbien der Kaffeerösterei Bohnenglück. Übergeordnet: Röstprofile.'
resource: http://127.0.0.1:8101/doc/kolumbien-JGjsbK1AEO
status: stable
generated:
  by: human:rita@bohnenglueck.test
  at: '2026-10-28T21:30:47.975Z'
---

# Kolumbien

Seite **Kolumbien** der Kaffeerösterei Bohnenglück. Übergeordnet: [Röstprofile](./../R%C3%B6stprofile.md).

* Punkt eins
* Punkt zwei