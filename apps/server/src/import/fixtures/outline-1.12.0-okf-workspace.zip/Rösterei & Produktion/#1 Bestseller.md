---
type: Document
title: '#1 Bestseller'
description: Unser Bestseller ist die Hausmischung (Link in die private Sammlung).
resource: http://127.0.0.1:8101/doc/1-bestseller-NpX2w5Y1Bc
status: stable
generated:
  by: human:rita@bohnenglueck.test
  at: '2026-10-28T21:30:48.173Z'
---

# #1 Bestseller

Unser Bestseller ist die [Hausmischung](./../Geheimrezepturen/Hausmischung%20%E2%80%9EBohnengl%C3%BCck%E2%80%9C.md) (Link in die private Sammlung).