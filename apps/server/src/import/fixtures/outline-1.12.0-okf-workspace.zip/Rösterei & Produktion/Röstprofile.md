---
type: Document
title: Röstprofile
description: Seite Röstprofile der Kaffeerösterei Bohnenglück.
resource: http://127.0.0.1:8101/doc/rostprofile-CIWgzpENUU
status: stable
generated:
  by: human:rita@bohnenglueck.test
  at: '2026-10-28T21:30:47.796Z'
---

# Röstprofile

Seite **Röstprofile** der Kaffeerösterei Bohnenglück.

* Punkt eins
* Punkt zwei