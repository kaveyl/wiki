---
type: Document
title: 'Qualität: Was ist „Crema“?'
description: 'Die Crema ist der Schaum auf dem Espresso. Frage: Wie dick? – 3–4 mm.'
resource: http://127.0.0.1:8101/doc/qualitat-was-ist-crema-WMk6i2gZkk
status: stable
generated:
  by: human:rita@bohnenglueck.test
  at: '2026-10-28T21:30:48.128Z'
---

# Qualität: Was ist „Crema“?

Die Crema ist der Schaum auf dem Espresso. Frage: *Wie dick?* – 3–4 mm.