---
type: Document
title: Rohkaffee-Einkauf
description: Seite Rohkaffee-Einkauf der Kaffeerösterei Bohnenglück.
resource: http://127.0.0.1:8101/doc/rohkaffee-einkauf-N8fTD4dGo6
status: stable
generated:
  by: human:rita@bohnenglueck.test
  at: '2026-10-28T21:30:48.189Z'
---

# Rohkaffee-Einkauf

Seite **Rohkaffee-Einkauf** der Kaffeerösterei Bohnenglück.

* Punkt eins
* Punkt zwei