---
type: Document
title: Trommelröster Nr. 1
description: 'Seite Trommelröster Nr. 1 der Kaffeerösterei Bohnenglück. Übergeordnet: Maschinen & Wartung.'
resource: http://127.0.0.1:8101/doc/trommelroster-nr-1-9OHpUUe5mL
status: stable
generated:
  by: human:rita@bohnenglueck.test
  at: '2026-10-28T21:30:48.050Z'
---

# Trommelröster Nr. 1

Seite **Trommelröster Nr. 1** der Kaffeerösterei Bohnenglück. Übergeordnet: [Maschinen & Wartung](./../Maschinen%20&%20Wartung.md).

* Punkt eins
* Punkt zwei