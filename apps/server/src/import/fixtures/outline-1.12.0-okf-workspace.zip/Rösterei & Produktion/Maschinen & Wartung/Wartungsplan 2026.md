---
type: Document
title: Wartungsplan 2026
description: 'Plan für 2026. Datei:'
resource: http://127.0.0.1:8101/doc/wartungsplan-2026-6yLvl1Qvqk
status: stable
generated:
  by: human:rita@bohnenglueck.test
  at: '2026-10-28T21:30:48.068Z'
---

# Wartungsplan 2026

Plan für 2026. Datei:

[Röstplan Oktober.pdf 589](uploads/80397680-792f-498c-8437-3bcaa0a6b688/fc68f8bd-ed56-4570-b424-02e745f4d3f2/R%C3%B6stplan%20Oktober.pdf)

Siehe auch [Trommelröster](./Trommelr%C3%B6ster%20Nr.%201.md).