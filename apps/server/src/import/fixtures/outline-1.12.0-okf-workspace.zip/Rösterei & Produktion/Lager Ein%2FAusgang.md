---
type: Document
title: Lager Ein/Ausgang
description: '(image: Lager Foto)'
resource: http://127.0.0.1:8101/doc/lager-einausgang-jhHhkmFIKz
status: stable
generated:
  by: human:rita@bohnenglueck.test
  at: '2026-10-28T21:30:48.143Z'
---

# Lager Ein/Ausgang

![Lager Foto](uploads/80397680-792f-498c-8437-3bcaa0a6b688/1aafe4e4-8b9e-4ca7-a822-29eee8cb90fc/Lager%20Foto.jpg)

Eingang wird jeden Montag gebucht.