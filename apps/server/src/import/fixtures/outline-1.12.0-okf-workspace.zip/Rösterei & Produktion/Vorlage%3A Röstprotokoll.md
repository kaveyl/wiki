---
type: Document
title: 'Vorlage: Röstprotokoll'
description: Röstprotokoll
resource: http://127.0.0.1:8101/doc/vorlage-rostprotokoll-zzYPTl3hP6
status: stable
generated:
  by: human:rita@bohnenglueck.test
  at: '2026-10-28T21:30:48.257Z'
---

# Vorlage: Röstprotokoll

## Röstprotokoll

| Feld | Wert |
|------|------|
| Datum |      |
| Herkunft |      |
| Gewicht |      |

- [ ] Röstgrad geprüft
- [ ] Probe abgefüllt