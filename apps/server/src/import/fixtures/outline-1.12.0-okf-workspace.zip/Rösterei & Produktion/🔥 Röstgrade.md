---
type: Document
title: 🔥 Röstgrade
description: Der Titel dieser Seite beginnt mit einem Emoji (ohne Outline-Icon).
resource: http://127.0.0.1:8101/doc/rostgrade-dtnyKdDRAw
status: stable
generated:
  by: human:rita@bohnenglueck.test
  at: '2026-10-28T21:30:47.995Z'
---

# 🔥 Röstgrade

Der Titel dieser Seite beginnt mit einem Emoji (ohne Outline-Icon).

| Röstgrad | Farbe | Geschmack |
|:---------|:-----:|----------:|
| Hell     | Zimt  | fruchtig  |
| Mittel   | Kastanie | ausgewogen |
| Dunkel   | Schokolade | kräftig   |


:::tip
Für Espresso eher **mittel bis dunkel** rösten.

:::