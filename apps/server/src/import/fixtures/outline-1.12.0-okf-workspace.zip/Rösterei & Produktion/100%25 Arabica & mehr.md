---
type: Document
title: 100% Arabica & mehr
description: Nur 100% Arabica & ein bisschen Robusta für die Crema.
resource: http://127.0.0.1:8101/doc/100-arabica-mehr-ikOstfkhyE
status: stable
generated:
  by: human:rita@bohnenglueck.test
  at: '2026-10-28T21:30:48.158Z'
---

# 100% Arabica & mehr

Nur 100% Arabica & ein bisschen Robusta für die Crema.