---
okf_version: '0.2'
---

# Collections

* [Geheimrezepturen](Geheimrezepturen/) - Nur für die Inhaberin.
* [Rösterei & Produktion](R%C3%B6sterei%20&%20Produktion/) - Alles rund ums Rösten.
* [Café & Verkauf](Caf%C3%A9%20&%20Verkauf/) - Café, Laden und Online-Shop.
* [Team-Handbuch](Team-Handbuch/) - Für alle im Team.
* [Café & Verkauf](Caf%C3%A9%20&%20Verkauf%20(1)/) - Zweite Sammlung mit gleichem Namen.
