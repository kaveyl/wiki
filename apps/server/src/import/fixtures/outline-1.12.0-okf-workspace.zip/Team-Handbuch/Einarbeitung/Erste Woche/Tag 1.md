---
type: Document
title: Tag 1
description: 'Seite Tag 1 der Kaffeerösterei Bohnenglück. Übergeordnet: Erste Woche.'
resource: http://127.0.0.1:8101/doc/tag-1-XuNxle9OoN
status: stable
generated:
  by: human:rita@bohnenglueck.test
  at: '2026-10-28T21:30:48.574Z'
---

# Tag 1

Seite **Tag 1** der Kaffeerösterei Bohnenglück. Übergeordnet: [Erste Woche](./../Erste%20Woche.md).

* Punkt eins
* Punkt zwei