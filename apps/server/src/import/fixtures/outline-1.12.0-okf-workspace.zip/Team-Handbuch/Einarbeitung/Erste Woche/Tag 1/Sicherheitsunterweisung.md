---
type: Document
title: Sicherheitsunterweisung
description: Vierte Ebene unter Team-Handbuch → Einarbeitung → Erste Woche → Tag 1.
resource: http://127.0.0.1:8101/doc/sicherheitsunterweisung-EYRAEWMpYi
status: stable
generated:
  by: human:rita@bohnenglueck.test
  at: '2026-10-28T21:30:48.592Z'
---

# Sicherheitsunterweisung

Vierte Ebene unter Team-Handbuch → Einarbeitung → Erste Woche → Tag 1.


1. Notausgänge zeigen
2. Feuerlöscher (CO₂) erklären
3. [Reinigungsplan](./../../../../R%C3%B6sterei%20&%20Produktion/Maschinen%20&%20Wartung/Reinigungsplan.md) durchgehen

Siehe auch [Willkommen bei Bohnenglück](./../../../Willkommen%20bei%20Bohnengl%C3%BCck.md).