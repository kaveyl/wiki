---
type: Document
title: Erste Woche
description: 'Seite Erste Woche der Kaffeerösterei Bohnenglück. Übergeordnet: Einarbeitung.'
resource: http://127.0.0.1:8101/doc/erste-woche-FVmFKX7YQe
status: stable
generated:
  by: human:rita@bohnenglueck.test
  at: '2026-10-28T21:30:48.558Z'
---

# Erste Woche

Seite **Erste Woche** der Kaffeerösterei Bohnenglück. Übergeordnet: [Einarbeitung](./../Einarbeitung.md).

* Punkt eins
* Punkt zwei