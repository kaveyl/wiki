---
type: Document
title: Urlaubsregelung
description: Seite Urlaubsregelung der Kaffeerösterei Bohnenglück.
resource: http://127.0.0.1:8101/doc/urlaubsregelung-wfpE6PgNwq
status: stable
generated:
  by: human:rita@bohnenglueck.test
  at: '2026-10-28T21:30:48.664Z'
---

# Urlaubsregelung

Seite **Urlaubsregelung** der Kaffeerösterei Bohnenglück.

* Punkt eins
* Punkt zwei