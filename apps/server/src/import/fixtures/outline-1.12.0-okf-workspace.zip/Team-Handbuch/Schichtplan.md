---
type: Document
title: Schichtplan
description: Tag
resource: http://127.0.0.1:8101/doc/schichtplan-5sXRFyRhge
status: stable
generated:
  by: human:rita@bohnenglueck.test
  at: '2026-10-28T21:30:48.624Z'
---

# Schichtplan

| Tag | Früh | Spät |
|-----|------|------|
| Mo  | Rita Röstmeister | Bruno Bohne |
| Di  | Bruno Bohne | Rita Röstmeister |
| Mi  | –    | –    |

Tabelle mit `Code` und **fett** in Zellen: | Pipe | im Text |