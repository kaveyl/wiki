---
type: Document
title: Formatierungen im Überblick
description: Alle Formatierungen, die Outline kennt.
resource: http://127.0.0.1:8101/doc/formatierungen-im-uberblick-XGejnWVaCa
status: stable
generated:
  by: human:rita@bohnenglueck.test
  at: '2026-10-28T21:30:48.650Z'
---

# Formatierungen im Überblick

Alle Formatierungen, die Outline kennt.

# Überschrift 1

## Überschrift 2

### Überschrift 3

**fett**, *kursiv*, ~~durchgestrichen~~, `Code`, ==hervorgehoben==, __unterstrichen__.

Zeile mit Umbruch  
zweite Zeile.


---

```python
def roeste(bohnen: str, minuten: int = 11) -> str:
    return f"{bohnen} nach {minuten} min"
```

```javascript
const preis = (g) => (g / 1000) * 24.5;
```

```mermaid
graph TD
  Rohkaffee --> Rösten --> Abkühlen --> Verpacken
```

```mermaidjs
sequenceDiagram
  Kunde->>Café: Bestellung
  Café-->>Kunde: Cappuccino
```

Inline-Mathe: $E = m \cdot c^2$ und Ausbeute $\frac{a}{b}$.

$$
\sum_{i=1}^{n} x_i = 42
$$

> Ein Zitat über Kaffee.
>
> Zweiter Absatz im Zitat.

+++++++
Versteckter Text im Toggle-Block.

* Punkt im Toggle

+++++++
Fußnote im Text[^1].

[^1]: Outline kennt keine Fußnoten – mal sehen, was übrig bleibt.


1. eins
2. zwei

   
   1. zwei-a
3. alpha
4. beta

Emoji-Kürzel :coffee: und direkt 🫘.

[Röstplan Oktober.pdf 589](uploads/80397680-792f-498c-8437-3bcaa0a6b688/fc68f8bd-ed56-4570-b424-02e745f4d3f2/R%C3%B6stplan%20Oktober.pdf)

Bild noch einmal:  ![Lager Foto](uploads/80397680-792f-498c-8437-3bcaa0a6b688/1aafe4e4-8b9e-4ca7-a822-29eee8cb90fc/Lager%20Foto.jpg)