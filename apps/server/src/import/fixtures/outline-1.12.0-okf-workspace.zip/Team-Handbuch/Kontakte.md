---
type: Document
title: Kontakte
description: 'Ansprechpartner: @Rita Röstmeister.'
resource: http://127.0.0.1:8101/doc/kontakte-Dc86MupeWt
status: stable
generated:
  by: human:rita@bohnenglueck.test
  at: '2026-10-28T21:30:48.692Z'
---

# Kontakte

Ansprechpartner: @[Rita Röstmeister](mention://25aa33c7-9f9a-4195-ac44-f45de6abfb45/user/80397680-792f-498c-8437-3bcaa0a6b688).