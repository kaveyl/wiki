---
type: Document
title: Speisekarte
description: Gleicher Titel wie in der ersten Sammlung.
resource: http://127.0.0.1:8101/doc/speisekarte-uAkOBfDeRM
status: stable
generated:
  by: human:rita@bohnenglueck.test
  at: '2026-10-28T21:34:18.451Z'
---

# Speisekarte

Gleicher Titel wie in der ersten Sammlung.