---
type: Document
title: Kassenabschluss
description: 'Abläufe beim Kassenabschluss:'
resource: http://127.0.0.1:8101/doc/kassenabschluss-BVjSLRUeFX
status: stable
generated:
  by: human:rita@bohnenglueck.test
  at: '2026-10-28T21:30:48.354Z'
---

# Kassenabschluss

Abläufe beim Kassenabschluss:

- [x] Bon-Rolle prüfen
- [ ] Bargeld zählen
  - [ ] Scheine
  - [x] Münzen
- [ ] Z-Bericht drucken

> Der Abschluss muss vor 19:00 Uhr fertig sein. — Rita