---
type: Document
title: 'Größe & Maße: Verpackung'
description: 'Größen: 250 g, 500 g & 1 kg. Maße: 12 × 8 × 20 cm.'
resource: http://127.0.0.1:8101/doc/grosse-masse-verpackung-AbIy8fDHUP
status: stable
generated:
  by: human:rita@bohnenglueck.test
  at: '2026-10-28T21:30:48.461Z'
---

# Größe & Maße: Verpackung

Größen: 250 g, 500 g & 1 kg. Maße: 12 × 8 × 20 cm.