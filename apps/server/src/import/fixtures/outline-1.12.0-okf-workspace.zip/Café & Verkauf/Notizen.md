---
type: Document
title: Notizen
description: Seite Notizen der Kaffeerösterei Bohnenglück.
resource: http://127.0.0.1:8101/doc/notizen-4fBtdXAJiM
status: stable
generated:
  by: human:rita@bohnenglueck.test
  at: '2026-10-28T21:30:48.382Z'
---

# Notizen

Seite **Notizen** der Kaffeerösterei Bohnenglück.

* Punkt eins
* Punkt zwei