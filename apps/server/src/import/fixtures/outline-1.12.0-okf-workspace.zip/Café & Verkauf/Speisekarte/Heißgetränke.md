---
type: Document
title: Heißgetränke
description: 'Seite Heißgetränke der Kaffeerösterei Bohnenglück. Übergeordnet: Speisekarte.'
resource: http://127.0.0.1:8101/doc/heissgetranke-lfEqObFcQY
status: stable
generated:
  by: human:rita@bohnenglueck.test
  at: '2026-10-28T21:30:48.293Z'
---

# Heißgetränke

Seite **Heißgetränke** der Kaffeerösterei Bohnenglück. Übergeordnet: [Speisekarte](./../Speisekarte.md).

* Punkt eins
* Punkt zwei