---
type: Document
title: Kuchen
description: 'Seite Kuchen der Kaffeerösterei Bohnenglück. Übergeordnet: Speisekarte.'
resource: http://127.0.0.1:8101/doc/kuchen-T2mSxHrpoQ
status: stable
generated:
  by: human:rita@bohnenglueck.test
  at: '2026-10-28T21:30:48.340Z'
---

# Kuchen

Seite **Kuchen** der Kaffeerösterei Bohnenglück. Übergeordnet: [Speisekarte](./../Speisekarte.md).

* Punkt eins
* Punkt zwei