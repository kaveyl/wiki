---
type: Document
title: Ristretto
description: 'Seite Ristretto der Kaffeerösterei Bohnenglück. Übergeordnet: Espresso-Varianten.'
resource: http://127.0.0.1:8101/doc/ristretto-Bj1Ffldc23
status: stable
generated:
  by: human:rita@bohnenglueck.test
  at: '2026-10-28T21:30:48.327Z'
---

# Ristretto

Seite **Ristretto** der Kaffeerösterei Bohnenglück. Übergeordnet: [Espresso-Varianten](./../Espresso-Varianten.md).

* Punkt eins
* Punkt zwei