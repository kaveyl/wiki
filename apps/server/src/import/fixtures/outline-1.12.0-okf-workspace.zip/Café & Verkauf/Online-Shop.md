---
type: Document
title: Online-Shop
description: Seite Online-Shop der Kaffeerösterei Bohnenglück.
resource: http://127.0.0.1:8101/doc/online-shop-zvPzT3Ayux
status: stable
generated:
  by: human:rita@bohnenglueck.test
  at: '2026-10-28T21:30:48.446Z'
---

# Online-Shop

Seite **Online-Shop** der Kaffeerösterei Bohnenglück.

* Punkt eins
* Punkt zwei