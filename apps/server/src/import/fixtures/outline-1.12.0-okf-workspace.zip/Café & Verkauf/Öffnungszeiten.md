---
type: Document
title: Öffnungszeiten
description: Seite Öffnungszeiten der Kaffeerösterei Bohnenglück.
resource: http://127.0.0.1:8101/doc/offnungszeiten-0zVbCFikty
status: stable
generated:
  by: human:rita@bohnenglueck.test
  at: '2026-10-28T21:30:48.369Z'
---

# Öffnungszeiten

Seite **Öffnungszeiten** der Kaffeerösterei Bohnenglück.

* Punkt eins
* Punkt zwei