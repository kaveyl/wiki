---
type: Document
title: Latte-Art-Kurs
description: Kurs am Samstag.
resource: http://127.0.0.1:8101/doc/latte-art-kurs-bXW5YVtWLO
status: stable
generated:
  by: human:rita@bohnenglueck.test
  at: '2026-10-28T21:32:49.670Z'
---

# Latte-Art-Kurs

Kurs am Samstag.

 ![Bohne dreht sich](uploads/80397680-792f-498c-8437-3bcaa0a6b688/63bb3bcb-1483-4d92-b611-7f2b717923f9/Bohne%20dreht%20sich.gif)

Video zur Vorbereitung:

https://www.youtube.com/watch?v=dQw4w9WgXcQ

Entwurf des Plakats:

https://www.figma.com/file/LKQ4FJ4bTnCSjedbRpk931/Plakat-Latte-Art

Als Link-Zeile (so legt der Editor Einbettungen ab):

<https://www.youtube.com/watch?v=aqz-KE-bpKQ>

<https://www.figma.com/file/LKQ4FJ4bTnCSjedbRpk931/Plakat_Latte_Art>

Echte Einbettungen (Editor):

[https://www.youtube.com/watch?v=aqz-KE-bpKQ](https://www.youtube.com/watch?v=aqz-KE-bpKQ)

[https://www.figma.com/file/LKQ4FJ4bTnCSjedbRpk931/Plakat%5FLatte%5FArt](https://www.figma.com/file/LKQ4FJ4bTnCSjedbRpk931/Plakat%5FLatte%5FArt)