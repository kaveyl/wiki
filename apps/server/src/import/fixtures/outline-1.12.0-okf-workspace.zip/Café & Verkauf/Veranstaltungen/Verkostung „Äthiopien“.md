---
type: Document
title: Verkostung „Äthiopien“
description: Verkostung mit Kaffee aus Yirgacheffe (andere Sammlung).
resource: http://127.0.0.1:8101/doc/verkostung-athiopien-Pz0ElMjOvU
status: stable
generated:
  by: human:rita@bohnenglueck.test
  at: '2026-10-28T21:30:48.428Z'
---

# Verkostung „Äthiopien“

Verkostung mit Kaffee aus [Yirgacheffe](./../../R%C3%B6sterei%20&%20Produktion/R%C3%B6stprofile/%C3%84thiopien/Yirgacheffe.md) (andere Sammlung).