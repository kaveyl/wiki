---
type: Document
title: Veranstaltungen
description: Seite Veranstaltungen der Kaffeerösterei Bohnenglück.
resource: http://127.0.0.1:8101/doc/veranstaltungen-hJy0u3sa9q
status: stable
generated:
  by: human:rita@bohnenglueck.test
  at: '2026-10-28T21:30:48.398Z'
---

# Veranstaltungen

Seite **Veranstaltungen** der Kaffeerösterei Bohnenglück.

* Punkt eins
* Punkt zwei